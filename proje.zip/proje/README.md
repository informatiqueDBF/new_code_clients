# Application Web Client Dashboard

## Description

Cette application web est composée de deux parties :
- **Backend** : API Laravel (PHP) qui gère les données clients, statistiques et notes
- **Frontend** : Interface utilisateur React avec Vite pour la gestion et visualisation des clients

L'application permet de gérer un portefeuille clients avec des fonctionnalités de recherche, filtrage, statistiques et système de notes (post-it).

## Prérequis

### Backend (Laravel)
- PHP 8.1 ou supérieur
- Composer
- SQLite ou MySQL/PostgreSQL
- Extension PHP : sqlite3, pdo_sqlite

### Frontend (React)
- Node.js 18.x ou supérieur
- NPM ou Yarn

### BDD (Mysql)

- Avoir une base de données qui ce nomme "recherche_client_v2"
- Mettre le fichier **bdd_(date)**
## Installation

**Important** : Après téléchargement depuis GitHub, les dépendances ne sont pas incluses dans le dépôt. Il est nécessaire d'installer les dépendances avant de pouvoir démarrer l'application.

### 1. Backend Laravel

```bash
cd backend
composer install
```

### 2. Frontend React

```bash
cd frontend
npm install
```

## Démarrage de l'application

### Étape 1 : Démarrer le backend

Ouvrir un terminal dans le dossier `backend` :
```bash
cd backend
php artisan serve --host=0.0.0.0 --port=8000
```

Le backend sera accessible sur : `http://192.168.0.22:8000`

### Étape 2 : Démarrer le frontend

Ouvrir un second terminal dans le dossier `frontend` :
```bash
cd frontend
npm run dev
```

Le frontend sera accessible sur : `http://localhost:5173`

## Architecture de l'application

### Backend Laravel
- **Routes API** : Définies dans `routes/api.php`
- **Contrôleurs** : Logique métier dans `app/Http/Controllers/`
- **Modèles** : Entités de données dans `app/Models/`
- **Base de données** : SQLite par défaut (`database/database.sqlite`)

### Frontend React
- **Pages** : Composants principaux dans `src/pages/`
- **Composants** : Composants réutilisables dans `src/components/`
- **Services** : Appels API dans `src/services/`
- **Styles** : Tailwind CSS pour le styling

## Fonctionnalités principales

### Dashboard Client
- Affichage des statistiques clients (actifs, douteux, prospects, sortis, administrateurs judiciaires)
- Recherche et filtrage des clients par nom et code
- Visualisation détaillée des fiches clients
- Gestion du portefeuille clients

### Système de Notes
- Création de post-it virtuels attachés aux clients
- Positionnement libre des notes sur un tableau
- Sauvegarde automatique des modifications

### Export de données
- Export Excel des listes de clients selon différents critères
- Export des logs d'importation

## Configuration réseau

L'application est configurée pour fonctionner en réseau local :
- Backend : `http://192.168.0.22:8000`
- Frontend : `http://localhost:5173`

Pour modifier l'adresse IP du backend, éditer les appels API dans le frontend (remplacer `192.168.0.22` par l'IP souhaitée).

## Développement

### Structure du projet
```
projet/
├── backend/          # API Laravel
│   ├── app/          # Code application
│   ├── routes/       # Routes API
│   └── database/     # Migrations et seeders
└── frontend/         # Interface React
    ├── src/          # Code source
    └── public/       # Fichiers statiques
```

### Commandes utiles

Backend :
```bash
php artisan route:list    # Lister les routes
php artisan migrate       # Exécuter les migrations
php artisan db:seed       # Charger les données de test
```

Frontend :
```bash
npm run build            # Build de production
npm run preview          # Prévisualiser le build
npm run lint             # Vérifier le code
```

## Débogage

### Logs Backend
Les logs Laravel sont disponibles dans `backend/storage/logs/laravel.log`

### Outils de développement
- React Developer Tools pour le frontend
- Network tab du navigateur pour les appels API
- Logs de la console navigateur pour le JavaScript

## Production

Pour déployer en production :
1. Configurer l'environnement Laravel (`.env`)
2. Exécuter `npm run build` dans le frontend
3. Configurer un serveur web (Apache/Nginx) pour servir les fichiers statiques
4. Configurer PHP-FPM pour le backend Laravel
