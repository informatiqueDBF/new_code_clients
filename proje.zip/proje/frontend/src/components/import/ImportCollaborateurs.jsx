import { useState } from 'react'
import axios from 'axios'
import { Upload, FileCheck, Download, UserCheck, CheckCircle, XCircle, Loader2 } from 'lucide-react'

const ImportCollaborateurs = () => {
  const [file, setFile] = useState(null)
  const [message, setMessage] = useState('')
  const [logUrl, setLogUrl] = useState('')
  const [nullCodes, setNullCodes] = useState([])
  const [errorCount, setErrorCount] = useState(0)
  const [loading, setLoading] = useState(false)

  const handleFileChange = (e) => {
    setFile(e.target.files[0])
    setMessage('')
    setLogUrl('')
    setNullCodes([])
    setErrorCount(0)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!file) return

    setLoading(true)
    const formData = new FormData()
    formData.append('fichier', file)

    try {
      const res = await axios.post("http://192.168.0.22:8000/api/import-collaborateurs", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      })

      const { créés, modifiés, erreurs, log, codes_null } = res.data
      const erreursReelles = erreurs - codes_null.length

      setMessage(`Créés : ${créés} | Modifiés : ${modifiés} | Erreurs : ${erreursReelles} | Codes null : ${codes_null.length}`)
      setNullCodes(codes_null)
      setErrorCount(erreursReelles)
      setLogUrl(`http://192.168.0.22:8000/storage/${log}`)
    } catch (err) {
      setMessage("Erreur lors de l'import.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-6 hover:shadow-2xl transition-all duration-300">
      {}
      <div className="flex items-center gap-3 mb-6">
        <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-xl shadow-lg">
          <UserCheck className="h-6 w-6 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-800">Import Collaborateurs</h3>
          <p className="text-sm text-gray-600">Base RH</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {}
        <div className="relative">
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleFileChange}
            className="w-full p-4 border-2 border-dashed border-purple-300 rounded-xl bg-purple-50/50 text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-gradient-to-r file:from-purple-600 file:to-purple-700 file:text-white hover:file:from-purple-700 hover:file:to-purple-800 hover:border-purple-400 transition-all duration-200"
          />
          {file && (
            <div className="absolute top-2 right-2">
              <FileCheck className="h-5 w-5 text-green-500" />
            </div>
          )}
        </div>

        {}
        <button 
          type="submit"
          disabled={!file || loading}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 text-white font-semibold rounded-xl shadow-lg shadow-purple-200 hover:from-purple-700 hover:via-purple-600 hover:to-purple-800 hover:shadow-xl hover:shadow-purple-300 focus:outline-none focus:ring-4 focus:ring-purple-300 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 active:scale-95"
        >
          {loading ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <Upload className="h-5 w-5" />
          )}
          {loading ? 'Import en cours...' : 'Importer'}
        </button>
      </form>

      {}
      {message && !message.includes("Erreur") && (
        <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="font-semibold text-green-800">Import terminé</span>
          </div>
          <p className="text-green-700 text-sm mb-3">{message}</p>
          
          {logUrl && (
            <a 
              href={logUrl} 
              download 
              target="_blank" 
              rel="noopener noreferrer" 
              className="inline-flex items-center gap-2 mb-3 px-3 py-2 bg-white rounded-lg border border-green-300 text-green-700 hover:bg-green-50 transition-colors text-sm font-medium"
            >
              <Download className="h-4 w-4" />
              Télécharger le log
            </a>
          )}
          
          {nullCodes.length > 0 && (
            <div className="mt-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <p className="font-medium text-yellow-800 text-sm mb-2">Codes vides détectés :</p>
              <ul className="list-disc pl-5 text-xs text-yellow-700 space-y-1">
                {nullCodes.map((code, i) => (
                  <li key={i}>{code}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {}
      {message && message.includes("Erreur") && (
        <div className="mt-6 p-4 bg-gradient-to-r from-red-50 to-rose-50 rounded-xl border border-red-200">
          <div className="flex items-center gap-2">
            <XCircle className="h-5 w-5 text-red-600" />
            <span className="font-semibold text-red-800">Erreur d'import</span>
          </div>
          <p className="text-red-700 mt-1 text-sm">{message}</p>
        </div>
      )}

      {}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <a
          href="http://192.168.0.22:8000/api/template/colaborateurs"
          className="inline-flex items-center gap-2 text-purple-700 hover:text-purple-900 font-medium text-sm transition-colors"
          download
        >
          <Download className="h-4 w-4" />
          Télécharger le template
        </a>
      </div>
    </div>
  )
}

export default ImportCollaborateurs

