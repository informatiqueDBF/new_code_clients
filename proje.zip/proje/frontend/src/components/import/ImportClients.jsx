import { useState } from 'react'
import axios from 'axios'
import { Upload, FileCheck, AlertCircle, Download, Users, CheckCircle, XCircle, AlertTriangle } from 'lucide-react'

const ImportClients = () => {
  const [file, setFile] = useState(null)
  const [result, setResult] = useState(null)
  const [logUrl, setLogUrl] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleFileChange = (e) => {
    setFile(e.target.files[0])
    setResult(null)
    setLogUrl(null)
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!file) return

    setLoading(true)
    const formData = new FormData()
    formData.append('fichier', file)

    try {
      const res = await axios.post("http://192.168.0.22:8000/api/import-clients", formData, {
        timeout: 120000
      })
      setResult(res.data)
      setLogUrl(`http://192.168.0.22:8000/storage/${res.data.log}`)
    } catch (err) {
      setError(err.response?.data?.error || 'Erreur lors de l\'import.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-6 hover:shadow-2xl transition-all duration-300">
      {}
      <div className="flex items-center gap-3 mb-6">
        <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-xl shadow-lg">
          <Users className="h-6 w-6 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-800">Import Clients</h3>
          <p className="text-sm text-gray-600">Fichier Agiris</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {}
        <div className="relative">
          <input
            type="file"
            onChange={handleFileChange}
            accept=".csv,.xlsx,.xls"
            className="w-full p-4 border-2 border-dashed border-purple-300 rounded-xl bg-purple-50/50 text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-gradient-to-r file:from-purple-600 file:to-purple-700 file:text-white hover:file:from-purple-700 hover:file:to-purple-800 hover:border-purple-400 transition-all duration-200"
          />
          {file && (
            <div className="absolute top-2 right-2">
              <FileCheck className="h-5 w-5 text-green-500" />
            </div>
          )}
        </div>

        {}
        <button 
          type="submit"
          disabled={!file || loading}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 text-white font-semibold rounded-xl shadow-lg shadow-purple-200 hover:from-purple-700 hover:via-purple-600 hover:to-purple-800 hover:shadow-xl hover:shadow-purple-300 focus:outline-none focus:ring-4 focus:ring-purple-300 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 active:scale-95"
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : (
            <Upload className="h-5 w-5" />
          )}
          {loading ? 'Import en cours...' : 'Importer'}
        </button>
      </form>

      {}
      {result && (
        <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="font-semibold text-green-800">Import terminé avec succès</span>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-green-700"><strong>Créés :</strong> {result.créés}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-blue-700"><strong>Modifiés :</strong> {result.modifiés}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
              <span className="text-red-700"><strong>Erreurs :</strong> {result.erreurs}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <span className="text-yellow-700"><strong>Codes null :</strong> {result.nulls}</span>
            </div>
          </div>
          {logUrl && (
            <a 
              href={logUrl} 
              target="_blank" 
              rel="noreferrer" 
              className="inline-flex items-center gap-2 mt-3 px-3 py-2 bg-white rounded-lg border border-green-300 text-green-700 hover:bg-green-50 transition-colors text-sm font-medium"
            >
              <Download className="h-4 w-4" />
              Télécharger le log
            </a>
          )}
        </div>
      )}

      {}
      {error && (
        <div className="mt-6 p-4 bg-gradient-to-r from-red-50 to-rose-50 rounded-xl border border-red-200">
          <div className="flex items-center gap-2">
            <XCircle className="h-5 w-5 text-red-600" />
            <span className="font-semibold text-red-800">Erreur d'import</span>
          </div>
          <p className="text-red-700 mt-1 text-sm">{error}</p>
        </div>
      )}

      {}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <a
          href="http://192.168.0.22:8000/api/template/clients"
          className="inline-flex items-center gap-2 text-purple-700 hover:text-purple-900 font-medium text-sm transition-colors"
          download
        >
          <Download className="h-4 w-4" />
          Télécharger le template
        </a>
      </div>
    </div>
  )
}

export default ImportClients
