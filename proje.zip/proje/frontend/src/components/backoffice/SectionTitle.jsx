export default function SectionTitle({ title }) {
    return <h2 className="text-xl font-semibold text-gray-800 mb-4">{title}</h2>
  }
  