import React from 'react'
import { Calendar, UserPlus, Clock, TrendingUp } from 'lucide-react'

export default function DerniereImportation({ date, crees }) {
  const formatDate = (dateString) => {
    if (!dateString) return 'Non disponible'
    try {
      const date = new Date(dateString)
      return date.toLocaleDateString('fr-FR', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    } catch {
      return dateString.replace(' ', ' à ')
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border border-blue-200 p-6">
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-xl">
            <Calendar className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-blue-700 mb-1">Dernière mise à jour</p>
            <p className="text-lg font-bold text-blue-900">
              {formatDate(date)}
            </p>
          </div>
        </div>
      </div>
      
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200 p-6">
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl">
            <UserPlus className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-green-700 mb-1">Clients créés</p>
            <div className="flex items-center gap-2">
              <p className="text-2xl font-bold text-green-900">{crees}</p>
              <TrendingUp className="h-5 w-5 text-green-600" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
