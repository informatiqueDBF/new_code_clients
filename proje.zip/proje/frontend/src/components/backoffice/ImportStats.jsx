export default function ImportStats({ data }) {
    return (
      <div className="bg-white p-4 rounded shadow grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 text-center">
        {Object.entries(data).map(([label, count]) => (
          <div key={label}>
            <p className="text-xl font-bold">{count}</p>
            <p className="text-sm text-gray-600">{label}</p>
          </div>
        ))}
      </div>
    );
  }
  