import React, { useEffect, useState } from 'react'
import Sidebar from './Sidebar'
import GraphCollaborateurs from './GraphCollaborateurs'
import GraphClientsParAn from './GraphClientsParAn'
import GraphOutils from './GraphOutils'
import GraphDepartements from './GraphDepartements'
import GraphTopApe from './GraphTopApe'
import GraphFormesJuridiques from './GraphFormesJuridiques'
import ImportStats from './ImportStats'
import axios from 'axios'
import DerniereImportation from './DerniereImportation'
import { BarChart3, TrendingUp, Users, FileText, Calendar, Database, Activity } from 'lucide-react'

export default function BackofficeDashboard() {
  const [data, setData] = useState(null)
  const [userData, setUserData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const fetchData = () => {
    setLoading(true)
    setError('')
    
    Promise.all([
      axios.get('http://192.168.0.22:8000/api/backoffice/graphs'),
      axios.get('http://192.168.0.22:8000/api/user/profile')
    ])
      .then(([dashboardRes, userRes]) => {
        setData(dashboardRes.data)
        setUserData(userRes.data)
        setLoading(false)
      })
      .catch(err => {
        console.error('Erreur API :', err)
        axios.get('http://192.168.0.22:8000/api/backoffice/graphs')
          .then(res => {
            setData(res.data)
            setLoading(false)
          })
          .catch(() => {
            setError('Erreur lors du chargement des données')
            setLoading(false)
          })
      })
  }

  useEffect(() => {
    fetchData()
  }, [])

  if (loading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar userData={userData} />
        <div className="flex-1 p-6 ml-64">
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <p className="text-xl text-gray-600">Chargement du tableau de bord...</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar userData={userData} />
        <div className="flex-1 p-6 ml-64">
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <div className="text-red-500 mb-4">❌</div>
              <p className="text-xl text-red-600 font-semibold mb-4">{error}</p>
              <button
                onClick={fetchData}
                className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors mx-auto"
              >
                <RefreshCw className="h-5 w-5" />
                Réessayer
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen w-full bg-gray-50">
      <Sidebar userData={userData} />
      <div className="flex-1 p-6 ml-64 w-full">
        <div className="w-full">
          {}
          <div className="mb-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-full mb-4 shadow-lg shadow-purple-300">
              <BarChart3 className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-purple-800 bg-clip-text text-transparent mb-2 drop-shadow-sm">
              Tableau de Bord
            </h1>
          </div>

          {}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <FileText className="h-6 w-6 text-purple-600 drop-shadow-sm" />
              <h2 className="text-2xl font-bold text-gray-800">Importations Excel</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {Object.entries(data.imports).map(([label, value], index) => {
                const icons = [Database, FileText, Users, Activity]
                const colors = [
                  'from-blue-500 to-cyan-600',
                  'from-green-500 to-emerald-600', 
                  'from-purple-500 to-pink-600',
                  'from-orange-500 to-red-600'
                ]
                const Icon = icons[index % icons.length]
                const colorClass = colors[index % colors.length]
                
                return (
                  <div key={label} className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100 hover:shadow-xl hover:shadow-purple-200 transition-all duration-300">
                    <div className="flex items-center gap-3">
                      <div className={`flex items-center justify-center w-12 h-12 bg-gradient-to-r ${colorClass} rounded-xl`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <p className="text-3xl font-bold text-gray-800">{value}</p>
                        <p className="text-sm text-gray-600 font-medium">{label}</p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <Calendar className="h-6 w-6 text-purple-600 drop-shadow-sm" />
              <h2 className="text-2xl font-bold text-gray-800">Dernière Importation</h2>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
              <DerniereImportation
                date={data.derniere_import.date}
                crees={data.derniere_import.crees}
              />
            </div>
          </div>
          
          {}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="h-6 w-6 text-purple-600 drop-shadow-sm" />
              <h2 className="text-2xl font-bold text-gray-800">Analyses Principales</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100 hover:shadow-xl hover:shadow-purple-200 transition-all duration-300 min-h-[500px]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Collaborateurs par Site</h3>
                  <div className="text-sm text-purple-600 font-medium">
                    Total: {Object.values(data.sites).reduce((a, b) => a + b, 0)}
                  </div>
                </div>
                <GraphCollaborateurs data={data.sites} />
              </div>
              
              <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100 hover:shadow-xl hover:shadow-purple-200 transition-all duration-300 min-h-[500px]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Clients par Année</h3>
                  <div className="text-sm text-purple-600 font-medium">
                    Total: {Object.values(data.clientsPerYear).reduce((a, b) => a + b, 0)}
                  </div>
                </div>
                <GraphClientsParAn data={data.clientsPerYear} />
              </div>
              
              <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100 hover:shadow-xl hover:shadow-purple-200 transition-all duration-300 min-h-[500px]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Outils Utilisés</h3>
                  <div className="text-sm text-purple-600 font-medium">
                    Total: {Object.values(data.outils).reduce((a, b) => a + b, 0)}
                  </div>
                </div>
                <GraphOutils data={data.outils} />
              </div>
            </div>
          </div>

          {}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <Activity className="h-6 w-6 text-purple-600 drop-shadow-sm" />
              <h2 className="text-2xl font-bold text-gray-800">Analyses Détaillées</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100 hover:shadow-xl hover:shadow-purple-200 transition-all duration-300 min-h-[500px]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Clients par Département</h3>
                  <div className="text-sm text-purple-600 font-medium">
                    Total: {Object.values(data.clientsParDepartement).reduce((a, b) => a + b, 0)}
                  </div>
                </div>
                <GraphDepartements data={data.clientsParDepartement} />
              </div>
              
              <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100 hover:shadow-xl hover:shadow-purple-200 transition-all duration-300 min-h-[500px]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Top APE</h3>
                  <div className="text-sm text-purple-600 font-medium">
                    Total: {Object.values(data.topApe).reduce((a, b) => a + b, 0)}
                  </div>
                </div>
                <GraphTopApe data={data.topApe} />
              </div>
              
              <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100 hover:shadow-xl hover:shadow-purple-200 transition-all duration-300 min-h-[500px]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Formes Juridiques</h3>
                  <div className="text-sm text-purple-600 font-medium">
                    Total: {Object.values(data.formesJuridiques).reduce((a, b) => a + b, 0)}
                  </div>
                </div>
                <GraphFormesJuridiques data={data.formesJuridiques} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
