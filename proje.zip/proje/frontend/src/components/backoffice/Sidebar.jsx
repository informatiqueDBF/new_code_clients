import { Home, Users, FileUp, FileDown, ClipboardList, BarChart3, Settings, LogOut, User } from 'lucide-react'

export default function Sidebar({ userData = null }) {
  const currentPath = window.location.pathname
  
  const menuItems = [
    { href: '/backoffice', icon: Home, label: 'Dashboard', active: currentPath === '/backoffice' },
    { href: '/collaborateurs', icon: Users, label: 'Collaborateurs', active: currentPath === '/collaborateurs' },
    { href: '/export', icon: FileDown, label: 'Export', active: currentPath === '/export' },
    { href: '/import', icon: FileUp, label: 'Import', active: currentPath === '/import' },
    { href: '/logs', icon: ClipboardList, label: 'Logs', active: currentPath === '/logs' },
  ]

  return (
    <div className="w-64 fixed bg-white border-r border-gray-200 h-full shadow-lg z-10">
      {}
      <div className="p-6 border-b border-gray-200">
        <div className="text-center">
          <a href="/" className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-purple-700 bg-clip-text text-transparent hover:from-purple-700 hover:to-purple-800 transition-all duration-200">
            DBF
          </a>
        </div>
      </div>

      {}
      <nav className="flex flex-col p-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon
          return (
            <a
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 group ${
                item.active
                  ? 'bg-gradient-to-r from-purple-600 to-purple-700 text-white shadow-lg shadow-purple-300'
                  : 'text-gray-600 hover:bg-purple-50 hover:text-purple-700'
              }`}
            >
              <Icon className={`h-5 w-5 ${item.active ? 'text-white' : 'text-gray-400 group-hover:text-purple-600'}`} />
              <span>{item.label}</span>
              {item.active && (
                <div className="ml-auto w-2 h-2 bg-white rounded-full opacity-80"></div>
              )}
            </a>
          )
        })}
      </nav>
    </div>
  )
}

