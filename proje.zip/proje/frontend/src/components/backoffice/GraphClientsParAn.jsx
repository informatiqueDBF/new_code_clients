import { Line } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend
} from 'chart.js'
import { Download, TrendingUp } from 'lucide-react'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend)

export default function GraphClientsParAn({ data }) {
  const sortedYears = Object.keys(data).sort((a, b) => parseInt(a) - parseInt(b))

  const chartData = {
    labels: sortedYears,
    datasets: [
      {
        label: 'Clients créés',
        data: sortedYears.map(year => data[year]),
        fill: false,
        borderColor: '#8b5cf6',
        backgroundColor: '#8b5cf6',
        tension: 0.4,
        pointBackgroundColor: '#8b5cf6',
        pointBorderColor: '#ffffff',
        pointBorderWidth: 2,
        pointRadius: 6,
        pointHoverRadius: 8,
        borderWidth: 3,
      },
    ],
  }

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { 
        position: 'top',
        labels: {
          font: {
            size: 12,
            weight: '500'
          },
          usePointStyle: true,
          padding: 20
        }
      },
      tooltip: { 
        mode: 'index', 
        intersect: false,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#ffffff',
        bodyColor: '#ffffff',
        borderColor: '#8b5cf6',
        borderWidth: 1,
        cornerRadius: 8,
      },
    },
    scales: {
      x: {
        display: true,
        title: { 
          display: true, 
          text: 'Année',
          color: '#6b7280',
          font: {
            size: 12,
            weight: '500'
          }
        },
        grid: {
          color: '#f3f4f6',
          borderColor: '#e5e7eb'
        },
        ticks: {
          color: '#6b7280',
          font: {
            size: 11
          }
        }
      },
      y: {
        display: true,
        title: { 
          display: true, 
          text: 'Nombre de clients',
          color: '#6b7280',
          font: {
            size: 12,
            weight: '500'
          }
        },
        beginAtZero: true,
        grid: {
          color: '#f3f4f6',
          borderColor: '#e5e7eb'
        },
        ticks: {
          color: '#6b7280',
          font: {
            size: 11
          }
        }
      }
    }
  }

  const total = Object.values(data).reduce((acc, val) => acc + val, 0)

  return (
    <div className="h-full flex flex-col">
      <div className="h-80 mb-4">
        <Line data={chartData} options={options} />
      </div>
      <div className="mt-auto">
        <a
          href="http://192.168.0.22:8000/api/export/clients-par-an"
          className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white text-sm font-medium rounded-lg hover:from-purple-700 hover:to-purple-800 transition-all duration-200 shadow-md hover:shadow-lg"
          target="_blank"
          rel="noopener noreferrer"
        >
          <Download className="h-4 w-4" />
          Exporter les données
        </a>
      </div>
    </div>
  )
}
