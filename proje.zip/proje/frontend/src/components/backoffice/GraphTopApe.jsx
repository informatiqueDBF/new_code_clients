import { Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend
} from 'chart.js'
import { Download, BarChart3 } from 'lucide-react'

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend)

export default function GraphTopApe({ data }) {
  const labels = Object.keys(data).map(label => {
    
    return label.length > 30 ? label.substring(0, 30) + '...' : label
  })

  const chartData = {
    labels: labels,
    datasets: [
      {
        label: 'Nombre de clients',
        data: Object.values(data),
        backgroundColor: 'rgba(139, 92, 246, 0.8)',
        borderColor: '#8b5cf6',
        borderWidth: 2,
        borderRadius: 4,
        borderSkipped: false,
      },
    ],
  }

  const total = Object.values(data).reduce((acc, val) => acc + val, 0)

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { 
        display: false 
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#ffffff',
        bodyColor: '#ffffff',
        borderColor: '#8b5cf6',
        borderWidth: 1,
        cornerRadius: 8,
        callbacks: {
          title: function(context) {
            
            return Object.keys(data)[context[0].dataIndex]
          },
          label: function(context) {
            const percentage = ((context.parsed.y / total) * 100).toFixed(1)
            return `Clients: ${context.parsed.y} (${percentage}%)`
          }
        }
      }
    },
    scales: {
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45,
          font: {
            size: 10
          },
          color: '#6b7280'
        },
        grid: {
          color: '#f3f4f6',
          borderColor: '#e5e7eb'
        }
      },
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Nombre de clients',
          color: '#6b7280',
          font: {
            size: 12,
            weight: '500'
          }
        },
        ticks: {
          color: '#6b7280',
          font: {
            size: 11
          }
        },
        grid: {
          color: '#f3f4f6',
          borderColor: '#e5e7eb'
        }
      }
    }
  }

  return (
    <div className="h-full flex flex-col">
      <div className="h-80 mb-4">
        <Bar data={chartData} options={options} />
      </div>
      <div className="mt-auto">
        <a
          href="http://192.168.0.22:8000/api/export/clients-par-ape"
          className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white text-sm font-medium rounded-lg hover:from-purple-700 hover:to-purple-800 transition-all duration-200 shadow-md hover:shadow-lg"
          target="_blank"
          rel="noopener noreferrer"
        >
          <Download className="h-4 w-4" />
          Exporter les données
        </a>
      </div>
    </div>
  )
}

