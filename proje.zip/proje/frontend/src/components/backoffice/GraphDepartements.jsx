import { Pie } from 'react-chartjs-2'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'
import { Download, MapPin } from 'lucide-react'
ChartJS.register(ArcElement, Tooltip, Legend)

export default function GraphDepartements({ data }) {
  const chartData = {
    labels: Object.keys(data),
    datasets: [
      {
        data: Object.values(data),
        backgroundColor: [
          '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', 
          '#ef4444', '#6366f1', '#f97316', '#ec4899', 
          '#22d3ee', '#84cc16', '#a855f7', '#14b8a6', 
          '#f43f5e', '#64748b', '#78716c'
        ],
        borderWidth: 0,
        hoverBorderWidth: 3,
        hoverBorderColor: '#ffffff',
      },
    ],
  }

  const total = Object.values(data).reduce((acc, val) => acc + val, 0)

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { 
        position: 'bottom',
        labels: {
          padding: 20,
          usePointStyle: true,
          maxWidth: 200,
          font: {
            size: 11,
            weight: '500'
          }
        }
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#ffffff',
        bodyColor: '#ffffff',
        borderColor: '#8b5cf6',
        borderWidth: 1,
        cornerRadius: 8,
        displayColors: true,
        callbacks: {
          label: function(context) {
            const percentage = ((context.parsed / total) * 100).toFixed(1)
            return `${context.label}: ${context.parsed} (${percentage}%)`
          }
        }
      }
    }
  }

  return (
    <div className="h-full flex flex-col">
      <div className="h-80 mb-4">
        <Pie data={chartData} options={options} />
      </div>
      <div className="mt-auto">
        <a
          href="http://192.168.0.22:8000/api/export/clients-par-departement"
          className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-700 text-white text-sm font-medium rounded-lg hover:from-purple-700 hover:to-purple-800 transition-all duration-200 shadow-md hover:shadow-lg"
          target="_blank"
          rel="noopener noreferrer"
        >
          <Download className="h-4 w-4" />
          Exporter les données
        </a>
      </div>
    </div>
  )
}
