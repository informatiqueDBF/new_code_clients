import { FaUserFriends, FaFileImport, FaFileExport, FaClipboardList } from 'react-icons/fa'

export default function Navbar() {
  return (
    <div className="bg-white shadow px-6 py-3 flex gap-6 items-center">
      <FaUserFriends className="text-blue-600" />
      <span className="text-sm font-semibold">Collaborateurs</span>

      <FaFileImport className="text-green-600" />
      <span className="text-sm font-semibold">Import</span>

      <FaFileExport className="text-yellow-600" />
      <span className="text-sm font-semibold">Export</span>

      <FaClipboardList className="text-gray-700" />
      <span className="text-sm font-semibold">Logs</span>
    </div>
  )
}
