import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { X, User, Mail, Phone, Building, Shield, Hash, UserCheck, UserX, Save, Loader2 } from 'lucide-react'

export default function CollaborateurModal({ isOpen, onClose, onSaved, existing }) {
  const [form, setForm] = useState({
    code: '',
    nom: '',
    email: '',
    tel: '',
    fonction: '',
    site: '',
    droit: '',
    present: true,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (existing) {
      setForm({
        code: existing.Code || '',
        nom: existing.Nom || '',
        email: existing.Email || '',
        tel: existing.Tel || '',
        fonction: existing.Fonction || '',
        site: existing.site || '',
        droit: existing.droit || 0,
        present: existing.present === 1 || existing.present === '1' || existing.present === 'oui',
      })
    } else {
      setForm({
        code: '',
        nom: '',
        email: '',
        tel: '',
        fonction: '',
        site: '',
        droit: 0,
        present: true,
      })
    }
  }, [existing, isOpen])

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target
    setForm(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
  }

  const handleSubmit = async () => {
    setLoading(true)
    setError('')
    
    try {
      
      const dataToSend = {
        ...form,
        present: form.present ? 1 : 0, 
        droit: parseInt(form.droit) || 0, 
      }
      
      if (existing) {
        
        await axios.put(`http://192.168.0.22:8000/api/collaborateurs/${existing.Code}`, dataToSend)
      } else {
        await axios.post('http://192.168.0.22:8000/api/collaborateurs', dataToSend)
      }
      onSaved()
      onClose()
    } catch (err) {
      setError('Erreur lors de l\'enregistrement du collaborateur')
      console.error('Erreur:', err)
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl shadow-purple-200 max-h-[90vh] overflow-y-auto">
        {}
        <div className="bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <User className="h-6 w-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">
                  {existing ? 'Modifier le collaborateur' : 'Nouveau collaborateur'}
                </h2>
                <p className="text-purple-100">
                  {existing ? 'Modifiez les informations ci-dessous' : 'Ajoutez un nouveau collaborateur à votre équipe'}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-white/80 hover:text-white hover:bg-white/20 rounded-full transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {}
        <div className="p-6">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
              <p className="text-red-600 text-sm font-medium">{error}</p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Code collaborateur
              </label>
              <div className="relative">
                <input
                  name="code"
                  placeholder="Code unique du collaborateur"
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200 disabled:bg-gray-100 disabled:text-gray-500"
                  value={form.code}
                  onChange={handleChange}
                  disabled={!!existing}
                />
                <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
              {existing && (
                <p className="text-xs text-gray-500 mt-1">Le code ne peut pas être modifié</p>
              )}
            </div>

            {}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nom complet
              </label>
              <div className="relative">
                <input
                  name="nom"
                  placeholder="Nom et prénom"
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  value={form.nom}
                  onChange={handleChange}
                />
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Adresse email
              </label>
              <div className="relative">
                <input
                  name="email"
                  type="email"
                  placeholder="collaborateur@entreprise.com"
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  value={form.email}
                  onChange={handleChange}
                />
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Numéro de téléphone
              </label>
              <div className="relative">
                <input
                  name="tel"
                  type="tel"
                  placeholder="01 23 45 67 89"
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  value={form.tel}
                  onChange={handleChange}
                />
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fonction / Poste
              </label>
              <div className="relative">
                <input
                  name="fonction"
                  placeholder="Développeur, Manager, etc."
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  value={form.fonction}
                  onChange={handleChange}
                />
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Site de travail
              </label>
              <div className="relative">
                <input
                  name="site"
                  placeholder="Paris, Lyon, Télétravail, etc."
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  value={form.site}
                  onChange={handleChange}
                />
                <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Niveau d'accès
              </label>
              <div className="relative">
                <select
                  name="droit"
                  value={form.droit}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                >
                  <option value={0}>Aucun accès (0)</option>
                  <option value={1}>Lecture seule (1)</option>
                  <option value={2}>Utilisateur (2)</option>
                  <option value={3}>Administrateur (3)</option>
                </select>
                <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Statut de présence
              </label>
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border-2 border-gray-200">
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="present"
                    checked={form.present === true}
                    onChange={() => setForm(prev => ({ ...prev, present: true }))}
                    className="sr-only"
                  />
                  <div className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    form.present === true 
                      ? 'bg-green-100 text-green-800 border-2 border-green-300' 
                      : 'bg-white text-gray-600 border-2 border-gray-200 hover:bg-green-50'
                  }`}>
                    <UserCheck className="h-5 w-5" />
                    <span className="font-medium">Présent</span>
                  </div>
                </label>
                
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="present"
                    checked={form.present === false}
                    onChange={() => setForm(prev => ({ ...prev, present: false }))}
                    className="sr-only"
                  />
                  <div className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    form.present === false 
                      ? 'bg-red-100 text-red-800 border-2 border-red-300' 
                      : 'bg-white text-gray-600 border-2 border-gray-200 hover:bg-red-50'
                  }`}>
                    <UserX className="h-5 w-5" />
                    <span className="font-medium">Absent</span>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {}
          <div className="flex items-center justify-end gap-4 mt-8 pt-6 border-t border-gray-200">
            <button
              onClick={onClose}
              className="px-6 py-3 text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors duration-200 font-medium"
              disabled={loading}
            >
              Annuler
            </button>
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 text-white font-medium rounded-xl shadow-lg shadow-purple-200 hover:from-purple-700 hover:via-purple-600 hover:to-purple-800 hover:shadow-xl hover:shadow-purple-300 transition-all duration-300 transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {loading ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Enregistrement...
                </>
              ) : (
                <>
                  <Save className="h-5 w-5" />
                  {existing ? 'Enregistrer les modifications' : 'Créer le collaborateur'}
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

