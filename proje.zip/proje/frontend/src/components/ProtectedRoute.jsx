import { useContext, useState, useEffect } from 'react'
import { AuthContext } from '../context/AuthContext'
import Login from '../pages/Login'
import { Loader2, Cog } from 'lucide-react'

export default function ProtectedRoute({ children }) {
  const { user, loading } = useContext(AuthContext)
  const [showLoading, setShowLoading] = useState(true)

  useEffect(() => {
    
    const timer = setTimeout(() => {
      setShowLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  if (loading || showLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          {}
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-full mb-6 shadow-lg shadow-purple-300">
            <Cog className="h-10 w-10 text-white animate-spin" />
          </div>
          
          {}
          <div className="mb-4">
            <Loader2 className="h-12 w-12 animate-spin text-purple-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-purple-800 bg-clip-text text-transparent mb-2">
              Chargement de tous les composants
            </h2>
            <p className="text-lg text-gray-600">Chargement en cours...</p>
          </div>
          
          {}
          <div className="flex justify-center space-x-2 mt-6">
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          </div>
        </div>
      </div>
    )
  }
  
  return user ? children : <Login />
}

