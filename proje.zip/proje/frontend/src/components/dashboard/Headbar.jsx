import { useContext, useState } from 'react'
import { AuthContext } from '../../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import { User, Settings, LogOut, Shield, ChevronDown } from 'lucide-react'

export default function Headbar() {
  const { user, logout } = useContext(AuthContext)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  const nomComplet = user?.Nom ?? 'null'
  let nom = 'null'
  let prenom = 'null'
  
  if (nomComplet !== 'null' && nomComplet.includes(' ')) {
    const parts = nomComplet.split(' ')
    nom = parts[0] 
    prenom = parts.slice(1).join(' ') 
  } else if (nomComplet !== 'null') {
    nom = nomComplet
    prenom = nomComplet
  }

  const handleLogout = async () => {
    await logout()
    navigate('/login')
  }

  return (
    <div className="bg-[#1f276a] text-white px-8 py-6 rounded-2xl shadow-2xl mb-8 relative">
      <div className="flex justify-between items-center">
        {}
        <div className="flex items-center gap-4">
          <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3">
            <User className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-wide">
              DBF <span className="text-gray-300">AUDIT</span>
            </h1>
            <p className="text-gray-300 text-sm">Plateforme de gestion client</p>
          </div>
        </div>

        {}
        <div className="relative">
          <button
            onClick={() => setOpen(!open)}
            className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-xl px-4 py-3 hover:bg-white/20 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-white/50"
          >
            <div className="bg-white/20 rounded-full p-2">
              <User className="h-5 w-5 text-white" />
            </div>
            <div className="text-left">
              <p className="font-medium text-white">
                {prenom !== 'null' ? `${prenom} ${nom}` : nom}
              </p>
              <p className="text-xs text-gray-300">
                {user?.Droit === 1 ? 'Administrateur' : 'Utilisateur'}
              </p>
            </div>
            <ChevronDown className={`h-4 w-4 text-white transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
          </button>

          {}
          {open && (
            <div className="absolute right-0 mt-3 w-64 bg-white rounded-2xl shadow-2xl shadow-purple-300 border border-gray-200 z-50 overflow-hidden">
              <div className="p-4 border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <div className="bg-purple-100 rounded-full p-2">
                    <User className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800">
                      {prenom !== 'null' ? `${prenom} ${nom}` : nom}
                    </p>
                    <p className="text-sm text-gray-500">
                      {user?.Droit === 1 ? 'Administrateur' : 'Utilisateur'}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="p-2">
                {user?.Droit === 1 && (
                  <button
                    onClick={() => {
                      setOpen(false)
                      navigate('/backoffice')
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-purple-50 rounded-xl transition-colors duration-200 text-gray-700"
                  >
                    <Shield className="h-5 w-5 text-purple-600" />
                    <span className="font-medium">Backoffice</span>
                  </button>
                )}
                
                <div className="border-t border-gray-100 my-2"></div>
                
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-red-50 rounded-xl transition-colors duration-200 text-red-600"
                >
                  <LogOut className="h-5 w-5" />
                  <span className="font-medium">Déconnexion</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}


