import { useEffect, useRef, useState } from 'react'
import { FaSearch } from 'react-icons/fa'
import axios from 'axios'

export default function ClientFilters({
  showPortefeuille,
  setShowPortefeuille,
  setSelectedClient,
  nom,
  code,
  setNom,
  setCode
}) {
  const [clientSortis, setclientSortis] = useState(true)
  const [results, setResults] = useState([])
  const [showDropdown, setShowDropdown] = useState(false)

  const codeInputRef = useRef(null)
  const dropdownRef = useRef(null)

  useEffect(() => {
    if (nom || code) {
      axios.get('http://192.168.0.22:8000/api/clients/search', {
        params: {
          portefeuille: showPortefeuille,
          client_sortis: clientSortis,
          nom,
          code
        }
      }).then(res => {
        setResults(res.data)
        setShowDropdown(true)
      })
    } else {
      setResults([])
      setShowDropdown(false)
    }
  }, [nom, code, clientSortis, showPortefeuille])

  const handleSelect = (client) => {
    setNom(client.Nom_complet)
    setCode(client.Code)
    setShowDropdown(false)
    setSelectedClient(client)
  }

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        !codeInputRef.current?.contains(event.target)
      ) {
        setShowDropdown(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div className="bg-white p-6 rounded shadow col-span-9">
      <div className="flex items-start justify-between gap-10">
        <div className="flex flex-col gap-6 pt-2">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={showPortefeuille}
              onChange={(e) => setShowPortefeuille(e.target.checked)}
              className="accent-blue-600 w-4 h-4"
            />
            <span className="text-gray-600 text-sm">Portefeuille</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={clientSortis}
              onChange={(e) => setclientSortis(e.target.checked)}
              className="accent-blue-600 w-4 h-4"
            />
            <span className="text-gray-600 text-sm">Client Sortis</span>
          </label>
        </div>

        <div className="flex-1">
          <h2 className="text-center text-2xl font-semibold text-gray-800 mb-6">Clients DBF Audit</h2>

          <div className="flex flex-col gap-4 relative">
            <div className="flex items-center gap-4">
              <label className="w-40 text-right text-sm text-gray-700">Nom de la société</label>
              <div className="relative flex-1">
                <input
                  type="text"
                  value={nom}
                  onChange={(e) => setNom(e.target.value)}
                  placeholder="Nom de la société"
                  className="w-full border border-gray-300 rounded-full px-5 py-2.5 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <FaSearch className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>

            <div className="flex items-center gap-4 relative" ref={codeInputRef}>
              <label className="w-40 text-right text-sm text-gray-700">Code société</label>
              <div className="relative flex-1">
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="Code"
                  className="w-full border border-gray-300 rounded-full px-5 py-2.5 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <FaSearch className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" />

                {showDropdown && results.length > 0 && (
                  <div
                    ref={dropdownRef}
                    className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-300 rounded-md shadow z-50 max-h-64 overflow-y-auto"
                  >
                    {results.map((client) => (
                      <div
                        key={client.Code}
                        onClick={() => handleSelect(client)}
                        className="px-4 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                      >
                        <strong>{client.Nom_complet}</strong> — {client.Code}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

