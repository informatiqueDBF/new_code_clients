import { useEffect, useState } from 'react'
import axios from 'axios'
import { Check, X, Settings, Database, Calculator, Users, FileText, Zap, Wrench } from 'lucide-react'

export default function ClientOutils({ client }) {
  const outils = [
    { key: 'isacompta_autonome', icon: Calculator, label: 'Isacompta Autonome' },
    { key: 'isanet_compta', icon: Database, label: 'Isanet Compta' },
    { key: 'isacompta_collaboratif', icon: Users, label: 'Isacompta Collaboratif' },
    { key: 'autre_logiciel', icon: Settings, label: 'Autre Logiciel' },
    { key: 'neant', icon: X, label: 'Néant' },
    { key: 'neoexpert', icon: Zap, label: 'Neoexpert' },
    { key: 'silae', icon: Wrench, label: 'Silae' }
  ]

  const [data, setData] = useState(null)

  useEffect(() => {
    if (!client?.Code) return

    axios.get(`http://192.168.0.22:8000/api/outils/${client.Code}`)
      .then(res => setData(res.data))
      .catch(() => setData(null))
  }, [client])

  if (!client) {
    return (
      <div className="text-center py-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-2xl mb-4">
          <Settings className="h-8 w-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-semibold text-gray-600 mb-2">Aucun client sélectionné</h3>
        <p className="text-gray-500">Sélectionnez un client pour voir ses outils</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
      {outils.map((outil) => {
        const actif = data?.[outil.key] === 1 || data?.[outil.key] === "1"
        const IconComponent = outil.icon
        
        return (
          <div 
            key={outil.key} 
            className={`group relative rounded-xl border-2 p-3 transition-all duration-300 hover:-translate-y-1 ${
              actif 
                ? 'border-green-300 bg-gradient-to-br from-green-50 to-emerald-50 shadow-md shadow-green-100' 
                : 'border-gray-200 bg-white shadow-md shadow-gray-100 hover:shadow-lg'
            }`}
          >
            {}
            <div className={`absolute -top-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center shadow-md ${
              actif ? 'bg-green-500' : 'bg-gray-400'
            }`}>
              {actif ? (
                <Check className="h-3 w-3 text-white" />
              ) : (
                <X className="h-3 w-3 text-white" />
              )}
            </div>

            {}
            <div className={`inline-flex items-center justify-center w-8 h-8 rounded-lg mb-2 ${
              actif 
                ? 'bg-green-500 shadow-md shadow-green-200' 
                : 'bg-gray-400 shadow-md shadow-gray-200'
            }`}>
              <IconComponent className="h-4 w-4 text-white" />
            </div>

            {}
            <h3 className={`font-medium text-xs leading-tight ${
              actif ? 'text-green-800' : 'text-gray-700'
            }`}>
              {outil.label}
            </h3>

            {}
            <div className="mt-1 flex items-center gap-1">
              <div className={`w-1.5 h-1.5 rounded-full ${actif ? 'bg-green-500' : 'bg-gray-400'}`}></div>
              <span className={`text-xs font-medium ${
                actif ? 'text-green-600' : 'text-gray-500'
              }`}>
                {actif ? 'Actif' : 'Inactif'}
              </span>
            </div>

            {}
            {actif && (
              <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-transparent via-white to-transparent opacity-0 group-hover:opacity-20 transition-opacity duration-300 transform -skew-x-12"></div>
            )}
          </div>
        )
      })}
    </div>
  )
}

