import { useEffect, useState } from 'react'
import axios from 'axios'
import { useAuth } from '../../context/AuthContext'

export default function ClientSummary() {
  const [stats, setStats] = useState(null)
  const { user } = useAuth()
  const code = user?.Code

  useEffect(() => {
    if (!code) return
    axios.get(`http://192.168.0.22:8000/api/client-stats/${code}`, { withCredentials: true })
      .then(res => {
        console.log('Client stats récupérées :', res.data)
        setStats(res.data)
      })
      .catch(err => console.error(err))
  }, [code])

  if (!stats) return null

  const total =
    stats.actifs +
    stats.douteux +
    stats.prospects +
    stats.sortis +
    stats.admin_judiciaire

  return (
    <div className="bg-white p-4 rounded shadow col-span-3">
      <h2 className="font-bold mb-2">Mes Clients</h2>
      {total > 0 ? (
        <ul className="text-sm space-y-1">
          <li>{stats.actifs} clients actifs</li>
          <li>{stats.douteux} clients douteux</li>
          <li>{stats.prospects} prospects</li>
          <li>{stats.sortis} clients sortis</li>
          <li>{stats.admin_judiciaire} administrateurs judiciaires</li>
        </ul>
      ) : (
        <p className="text-center text-gray-400">Aucun client</p>
      )}
    </div>
  )
}
