import Modal from 'react-modal'
import { useEffect, useState } from 'react'
import axios from 'axios'
import PostItBoard from './PostItBoard'

Modal.setAppElement('#root')

export default function ClientInfos({ client }) {
  const [collaborateurs, setCollaborateurs] = useState({})
  const [modalOpen, setModalOpen] = useState(false)
  const [selectedCollab, setSelectedCollab] = useState(null)

  const roles = [
    { key: 'Responsable_Code', label: 'Responsable' },
    { key: 'Chef_de_mission_Code', label: 'Chef de mission' },
    { key: 'Collaborateur_Code', label: 'Collaborateur' }
  ]

  useEffect(() => {
    const fetchCollaborateur = async (label, code) => {
      if (!code) return
      try {
        const res = await axios.get(`http://192.168.0.22:8000/api/collaborateurs/${code}`)
        setCollaborateurs(prev => ({ ...prev, [label]: res.data }))
      } catch {
        setCollaborateurs(prev => ({ ...prev, [label]: null }))
      }
    }

    setCollaborateurs({})
    roles.forEach(({ key, label }) => {
      if (client?.[key]) {
        fetchCollaborateur(label, client[key])
      }
    })
  }, [client])

  const openModal = (data) => {
    setSelectedCollab(data)
    setModalOpen(true)
  }

  const closeModal = () => {
    setModalOpen(false)
    setSelectedCollab(null)
  }

  return (
    <div className="col-span-3 bg-white p-4 rounded shadow">
      <h2 className="text-lg font-semibold mb-2">Interlocuteurs DBF</h2>
      {client ? (
        <div className="text-sm mb-4 space-y-2">
          {roles.map(({ key, label }) => {
            const collab = collaborateurs[label]
            return client[key] && collab ? (
              <div key={label}>
                <p>
                  <strong>{label} :</strong>{' '}
                  <span
                    className="text-blue-600 hover:underline cursor-pointer"
                    onClick={() => openModal(collab)}
                  >
                    {collab.nom}
                  </span>
                </p>
                <p><strong>Fonction :</strong> {collab.fonction}</p>
              </div>
            ) : null
          })}
        </div>
      ) : (
        <div className="h-20 bg-gray-100 rounded mb-2" />
      )}

      <hr className="my-4 border-gray-300" />

      <h2 className="text-lg font-semibold mb-2">Adresse</h2>
      {client ? (
        <div className="text-sm space-y-1">
          {['adresse', 'adresse_1', 'adresse_2', 'adresse_3', 'code_postal', 'commune', 'departement_libelle'].map(key => (
            client[key] && client[key].trim() !== '' && (
              <p key={key}>{client[key]}</p>
            )
          ))}
          <a
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([
              client?.adresse,
              client?.adresse_1,
              client?.adresse_2,
              client?.adresse_3,
              client?.code_postal,
              client?.commune,
              client?.departement_libelle
            ].filter(Boolean).join(', '))}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 hover:underline inline-block mt-2"
          >
            📍 Voir sur Google Maps
          </a>
        </div>
      ) : (
        <div className="h-20 bg-gray-100 rounded" />
      )}
      
      <Modal
        isOpen={modalOpen}
        onRequestClose={closeModal}
        contentLabel="Détails collaborateur"
        className="w-full max-w-lg bg-white rounded-xl p-6 shadow-lg outline-none"
        overlayClassName="fixed inset-0 bg-black bg-opacity-40 z-50 flex items-center justify-center"
      >
        {selectedCollab && (
          <>
            <h3 className="text-2xl font-semibold text-gray-800 mb-4">{selectedCollab.nom}</h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p><strong>Code :</strong> {selectedCollab.code}</p>
              <p><strong>Site :</strong> {selectedCollab.site}</p>
              <p><strong>Fonction :</strong> {selectedCollab.fonction}</p>
              <p>
                <strong>Email :</strong>{' '}
                <a href={`mailto:${selectedCollab.email}`} className="text-blue-600 underline">
                  {selectedCollab.email}
                </a>
              </p>
              <p>
                <strong>Téléphone :</strong>{' '}
                <a
                  href={`https://teams.microsoft.com/l/call/0/0?users=${selectedCollab.email}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 underline"
                >
                  {selectedCollab.tel}
                </a>
              </p>
            </div>

            <div className="mt-6 flex justify-between items-center gap-4">
              <button
                onClick={closeModal}
                className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-6 py-2 rounded-lg"
              >
                Fermer
              </button>
              <button
                onClick={() => window.open(`/portefeuille/${selectedCollab.code}`, '_blank')}
                className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg"
              >
                Voir le portefeuille
              </button>
            </div>
          </>
        )}
      </Modal>
      {}

    </div>
  )
}

