import React from 'react'

export default function StatCard({ 
  label, 
  value, 
  icon: Icon, 
  color = "from-purple-500 to-purple-600",
  bgColor = "bg-purple-50",
  textColor = "text-purple-700"
}) {
  return (
    <div className="group bg-white rounded-2xl border border-gray-200 p-6 shadow-lg shadow-purple-100 hover:shadow-xl hover:shadow-purple-200 transition-all duration-300 hover:-translate-y-1">
      <div className="flex items-center justify-between mb-4">
        <div className={`inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r ${color} rounded-xl shadow-lg`}>
          {Icon && <Icon className="h-6 w-6 text-white" />}
        </div>
        <div className={`px-3 py-1 ${bgColor} rounded-full`}>
          <span className={`text-sm font-medium ${textColor}`}>Actuel</span>
        </div>
      </div>
      
      <div className="space-y-2">
        <p className="text-3xl font-bold text-gray-800 group-hover:text-purple-600 transition-colors">
          {value?.toLocaleString() || 0}
        </p>
        <p className="text-sm font-medium text-gray-600 leading-tight">
          {label}
        </p>
      </div>
    </div>
  )
}
  