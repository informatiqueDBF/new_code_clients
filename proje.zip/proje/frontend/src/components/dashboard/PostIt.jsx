import React, { useState, useRef } from 'react';
import Draggable from 'react-draggable';
import axios from 'axios';

const COLORS = ['#FFFB7D', '#FFD1DC', '#B5F7A5', '#A5D8F7'];

export default function PostIt({ id, position_x, position_y, contenu, couleur, fichier, onUpdate, onDelete }) {
  const [text, setText] = useState(contenu || '');
  const [color, setColor] = useState(couleur || '#FFFB7D');
  const [pendingFiles, setPendingFiles] = useState([]);
  const [uploadedFiles, setUploadedFiles] = useState(fichier ? [fichier] : []);
  const nodeRef = useRef(null);

  const handleStop = (e, data) => {
    onUpdate(id, { position_x: data.x, position_y: data.y });
  };

  const handleSave = () => {
    onUpdate(id, { contenu: text });
  };

  const handleColorChange = (c) => {
    setColor(c);
    onUpdate(id, { couleur: c });
  };

  const handleFileInput = (e) => {
    const files = Array.from(e.target.files);
    setPendingFiles(prev => [...prev, ...files]);
  };

  const handleUploadFile = async (file, index) => {
    const formData = new FormData();
    formData.append('fichier', file);
    try {
      const res = await axios.post(`http://192.168.0.22:8000/api/notes/${id}/upload`, formData);
      setUploadedFiles(prev => [...prev, res.data.path]);
      setPendingFiles(prev => prev.filter((_, i) => i !== index));
      onUpdate(id, { fichier: res.data.path }); 
    } catch (err) {
      console.error('Erreur upload fichier :', err);
    }
  };

  const handleRemovePendingFile = (index) => {
    setPendingFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleRemoveUploadedFile = (filePath) => {
    setUploadedFiles(prev => prev.filter(f => f !== filePath));
    
  };

  return (
    <Draggable
      defaultPosition={{ x: position_x, y: position_y }}
      onStop={handleStop}
      nodeRef={nodeRef}
    >
      <div
        ref={nodeRef}
        style={{ backgroundColor: color }}
        className="absolute w-60 min-h-[16rem] p-3 rounded shadow-md border z-50 flex flex-col justify-between"
      >
        <textarea
          className="w-full h-24 resize-none outline-none bg-transparent text-sm"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />

        <div className="flex gap-1 mt-1 mb-1">
          {COLORS.map(c => (
            <div
              key={c}
              onClick={() => handleColorChange(c)}
              className="w-4 h-4 rounded-full border cursor-pointer"
              style={{ backgroundColor: c }}
            />
          ))}
        </div>

        <input
          type="file"
          multiple
          onChange={handleFileInput}
          className="text-xs mb-1"
        />

        {}
        {pendingFiles.length > 0 && (
          <div className="text-xs space-y-1">
            {pendingFiles.map((file, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="truncate">{file.name}</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleUploadFile(file, index)}
                    className="text-green-600 font-bold"
                  >
                    ✔
                  </button>
                  <button
                    onClick={() => handleRemovePendingFile(index)}
                    className="text-red-600 font-bold"
                  >
                    ✖
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {}
        {uploadedFiles.length > 0 && (
          <div className="text-xs mt-2 space-y-1">
            {uploadedFiles.map((path, i) => (
              <div key={i} className="flex justify-between items-center">
                <a
                  href={`http://192.168.0.22:8000/storage/${path}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-blue-600 underline truncate"
                >
                  📎 {path.split('/').pop()}
                </a>
                <button
                  onClick={() => handleRemoveUploadedFile(path)}
                  className="text-red-500 ml-2"
                >
                  ✖
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex justify-end gap-2 mt-2">
          <button
            onClick={handleSave}
            className="text-green-600 hover:text-green-800 font-bold text-sm"
            title="Valider"
          >
            ✔
          </button>
          <button
            onClick={() => onDelete(id)}
            className="text-red-600 hover:text-red-800 font-bold text-sm"
            title="Supprimer"
          >
            ✖
          </button>
        </div>
      </div>
    </Draggable>
  );
}

