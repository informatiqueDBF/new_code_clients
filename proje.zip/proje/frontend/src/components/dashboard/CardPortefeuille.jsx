export default function CardPortefeuille({ client, code }) {
    let fonction = ''
    if (client.Collaborateur_Code === code) fonction = 'Collaborateur'
    else if (client.Chef_de_mission_Code === code) fonction = 'Chef de mission'
    else if (client.Responsable_Code === code) fonction = 'Responsable'
  
    return (
      <div className="bg-white border rounded-lg shadow p-4 mb-4">
        <h3 className="font-bold text-lg">{client.Code} – {client.Nom_complet}</h3>
        <p className="text-sm text-blue-600 font-semibold">{fonction}</p>
        <div className="text-sm mt-2 space-y-1">
          {}
          {client.Date_creation && <p>Date de création : {client.Date_creation}</p>}
        </div>
      </div>
    )
  }
  
