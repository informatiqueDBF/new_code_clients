export default function ClientFiche({ client }) {
  const excludedFields = [
    'Responsable_Code', 'Chef_de_mission_Code', 'Collaborateur_Code',
    'departement', 'departement_libelle', 'adresse', 'adresse_1',
    'adresse_2', 'adresse_3', 'code_postal', 'commune', 'created_at', 'updated_at'
  ]

  const labels = {
    Code: 'Code',
    Nom_complet: 'Nom complet',
    Qualification: 'Qualification',
    Famille: 'Famille',
    Nature: 'Nature',
    Titre: 'Titre',
    Nom_denomination: 'Nom dénomination',
    Nom_commercial: 'Nom commercial',
    Forme_juridique: 'Forme juridique',
    Tel_fax: 'Fax',
    Tel: 'Téléphone',
    Email: 'Email',
    Date_creation: 'Date création',
    Tva: 'TVA',
    Siret: 'SIRET',
    Ape_code: 'Code APE',
    Ape_libelle: 'Libellé APE',
    Nafu_code: 'Code NAFU',
    Nafu_libelle: 'Libellé NAFU',
    Activite_exercer: 'Activité exercée',
    Activite: 'Activité',
    Activite_libelle: 'Libellé activité',
    Rcs: 'RCS',
    numero: 'Numéro',
  }

  const formatValue = (key, value) => {
    if (key === 'Email') {
      return <a href={`mailto:${value}`} className="text-blue-600 hover:underline">{value}</a>
    }
    if (key === 'Tel') {
      return <a href={`callto:${value}`} className="text-blue-600 hover:underline">{value}</a>
    }
    return value
  }

  return (
    <div className="col-span-6 bg-white p-4 rounded shadow">
      <h2 className="font-bold mb-2">Fiche Société</h2>
      {client ? (
        <div className="grid grid-cols-2 gap-4 text-sm">
          {Object.entries(client)
            .filter(([key, value]) => !excludedFields.includes(key) && value && value.trim() !== '')
            .map(([key, value]) => (
              <div key={key}>
                <p className="text-gray-500">{labels[key] || key}</p>
                <p className="font-semibold">{formatValue(key, value)}</p>
              </div>
            ))}
        </div>
      ) : (
        <div className="h-80 bg-gray-100 rounded" />
      )}
    </div>
  )
}