import { useEffect, useState } from 'react'
import axios from 'axios'
import CardPortefeuille from './CardPortefeuille'
import { useAuth } from '../../context/AuthContext'

export default function ClientPortefeuille({ onSelectClient = () => {}, selectedClient = null, setSearchNom = () => {}, setSearchCode = () => {} }) {
  const { user } = useAuth()
  const code = user?.Code
  const [clients, setClients] = useState([])
  const [search, setSearch] = useState('')
  const [filtered, setFiltered] = useState([])

  useEffect(() => {
    if (!code) return
    axios.get(`http://192.168.0.22:8000/api/client-stats/${code}`, { withCredentials: true })
      .then(res => {
        const list = res.data.clients || []
        setClients(list)
        setFiltered(list)
      })
      .catch(err => console.error(err))
  }, [code])

  useEffect(() => {
    if (!search) return setFiltered(clients)
    setFiltered(
      clients.filter(client =>
        client.Nom_complet?.toLowerCase().includes(search.toLowerCase()) ||
        client.Code?.toLowerCase().includes(search.toLowerCase())
      )
    )
  }, [search, clients])

  const handleClick = async (client) => {
    setSearchNom(client.Nom_complet || '')
    setSearchCode(client.Code || '')
  
    try {
      const res = await axios.get(`http://192.168.0.22:8000/api/clients/${client.Code}`)
      onSelectClient(res.data)
    } catch {
      onSelectClient(null)
    }
  }

  return (
    <div className="col-span-3 bg-white p-4 rounded shadow border-blue-400 border-2 flex flex-col">
      <h2 className="font-bold mb-4 text-lg">Portefeuille</h2>

      <input
        type="text"
        placeholder="Rechercher..."
        value={search}
        onChange={e => setSearch(e.target.value)}
        className="mb-4 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
      />

      <div className="overflow-y-auto flex-1 pr-1" style={{ maxHeight: '400px' }}>
        {filtered.length > 0 ? (
          filtered.map(client => {
            const isSelected = selectedClient && client.Code === selectedClient.Code
            return (
              <div
                key={client.Code}
                onClick={() => handleClick(client)}
                className={`cursor-pointer rounded-md border mb-2 p-2 transition-colors ${isSelected ? 'bg-blue-100 border-blue-500' : 'bg-white border-gray-200 hover:bg-gray-50'}`}
              >
                <CardPortefeuille client={client} code={code} />
              </div>
            )
          })
        ) : (
          <p className="text-center text-gray-400">Aucun client</p>
        )}
      </div>
    </div>
  )
}

