import React, { useEffect, useState } from 'react';
import axios from 'axios';
import PostIt from './PostIt';

export default function PostItBoard({ clientCode }) {
  const [postIts, setPostIts] = useState([]);

  useEffect(() => {
    if (clientCode) {
      axios.get(`http://192.168.0.22:8000/api/clients/${clientCode}/notes`)
        .then(res => setPostIts(res.data));
    }
  }, [clientCode]);

  const handleCreate = async () => {
    const res = await axios.post(`http://192.168.0.22:8000/api/clients/${clientCode}/notes`, {
      position_x: -300, 
      position_y: -300, 
      couleur: '#FFFB7D',
      contenu: ''
    });
  
    setPostIts(prev => [...prev, res.data]);
  };

  const handleUpdate = async (id, updates) => {
    await axios.put(`http://192.168.0.22:8000/api/notes/${id}`, updates);
    setPostIts(prev => prev.map(p => (p.id === id ? { ...p, ...updates } : p)));
  };

  const handleDelete = async (id) => {
    await axios.delete(`http://192.168.0.22:8000/api/notes/${id}`);
    setPostIts(prev => prev.filter(p => p.id !== id));
  };

  return (
    <>
      {postIts.map(note => (
        <PostIt key={note.id} {...note} onUpdate={handleUpdate} onDelete={handleDelete} />
      ))}
    </>
  );
}

