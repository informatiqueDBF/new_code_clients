import React, { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const CollabMap = () => {
  const { code } = useParams();
  const mapRef = useRef(null);
  const [clients, setClients] = useState([]);
  const [filteredClients, setFilteredClients] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (mapRef.current) return;

    const map = L.map('mapContainer').setView([48.85, 2.35], 6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    mapRef.current = map;
  }, []);

  useEffect(() => {
    if (!mapRef.current) return;

    const fetchClients = async () => {
      try {
        const res = await axios.get(`http://192.168.0.22:8000/api/clients-par-collab/${code}`);
        const actifs = res.data.filter(client =>
          !['Prospect', 'prospect', 'prospects', 'Clients sortis', 'clients sortis'].includes(client.Famille)
        );

        const results = await Promise.allSettled(actifs.map(async (client) => {
          const query = [
            client.adresse,
            client.adresse_1,
            client.adresse_2,
            client.adresse_3,
            client.code_postal,
            client.commune,
            client.departement_libelle
          ].filter(Boolean).join(', ');

          if (!query.trim()) return null;

          try {
            const { data } = await axios.get('https://photon.komoot.io/api/', {
              params: { q: query, limit: 1, lang: 'fr' }
            });

            const coords = data.features?.[0]?.geometry?.coordinates;
            if (!coords) return null;

            client.position = { lat: coords[1], lon: coords[0] };

            if (client.Collaborateur_Code === code) client.fonction = 'Collaborateur';
            else if (client.Responsable_Code === code) client.fonction = 'Responsable';
            else if (client.Chef_de_mission_Code === code) client.fonction = 'Chef de mission';

            return client;
          } catch {
            return null;
          }
        }));

        const geocodedClients = results
          .filter(r => r.status === 'fulfilled' && r.value && r.value.position)
          .map(r => r.value);

        setClients(geocodedClients);
        setFilteredClients(geocodedClients);
        setLoading(false);

        geocodedClients.forEach(client => {
          const popupContent = `
            <div style="padding:8px;max-width:250px;">
              <strong>${client.Nom_complet}</strong><br/>
              Code : ${client.Code}<br/>
              Fonction : ${client.fonction || 'N/A'}<br/>
              Famille : ${client.Famille}<br/>
              Créé le : ${client.Date_creation || 'inconnue'}<br/>
              <a href="callto:${client.Tel}" target="_blank" style="color:#0078d4;text-decoration:underline;">Téléphone : ${client.Tel || 'Non renseigné'}</a><br/>
              <a href="mailto:${client.Email}" target="_blank" style="color:#0078d4;text-decoration:underline;">Email : ${client.Email || 'Non renseigné'}</a>
            </div>
          `;

          L.marker([client.position.lat, client.position.lon])
            .addTo(mapRef.current)
            .bindPopup(popupContent);
        });
      } catch (e) {
        console.error('Erreur de chargement des clients :', e);
        setLoading(false);
      }
    };

    fetchClients();
  }, [code]);

  const handleClientClick = (client) => {
    if (client.position && mapRef.current) {
      mapRef.current.setView([client.position.lat, client.position.lon], 14);
    }
  };

  const handleSearch = (e) => {
    const value = e.target.value.toLowerCase();
    setSearch(value);
    setFilteredClients(
      clients.filter(c =>
        c.Nom_complet?.toLowerCase().includes(value) ||
        c.Code?.toLowerCase().includes(value)
      )
    );
  };

  return (
    <div style={{ display: 'flex' }}>
      <div style={{ width: '25%', height: '100vh', padding: '10px', boxSizing: 'border-box', backgroundColor: '#f9f9f9', borderRight: '1px solid #ccc', overflowY: 'auto' }}>
        {loading ? (
          <p>Chargement des clients...</p>
        ) : (
          <>
            <input
              type="text"
              placeholder="Rechercher par code ou nom"
              value={search}
              onChange={handleSearch}
              style={{ width: '100%', padding: '8px', marginBottom: '10px', borderRadius: '4px', border: '1px solid #ccc' }}
            />
            {filteredClients.map((client, index) => (
              <div key={index} onClick={() => handleClientClick(client)} style={{ marginBottom: '10px', cursor: 'pointer', padding: '6px 4px', borderBottom: '1px solid #ddd' }}>
                <strong>{client.Nom_complet}</strong><br />
                <span style={{ fontSize: '12px', color: '#666' }}>{client.Code}</span>
              </div>
            ))}
          </>
        )}
      </div>
      <div id="mapContainer" style={{ width: '75%', height: '100vh' }}></div>
    </div>
  );
};

export default CollabMap;
