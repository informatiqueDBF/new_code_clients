import React from 'react'
import Sidebar from '../components/backoffice/Sidebar'
import ImportClients from '../components/import/ImportClients'
import ImportCollaborateurs from '../components/import/ImportCollaborateurs'
import ImportNeoexpert from '../components/import/ImportNeoexpert'
import ImportSilae from '../components/import/ImportSilae'
import { Upload, FileText, Database } from 'lucide-react'

export default function ImportPage() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 p-6 ml-64">
        <div className="max-w-7xl mx-auto">
          {}
          <div className="mb-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-full mb-4 shadow-lg shadow-purple-300">
              <Upload className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-purple-800 bg-clip-text text-transparent mb-2 drop-shadow-sm">
              Import de données
            </h1>
          </div>

          {}
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8 shadow-lg shadow-purple-100">
            <div className="flex items-center gap-3 mb-4">
              <FileText className="h-6 w-6 text-purple-600 drop-shadow-sm" />
              <h3 className="text-xl font-semibold text-gray-800">Formats supportés</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
              <div className="flex items-center gap-2 p-3 bg-purple-50 rounded-lg border border-purple-200">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <span className="text-sm text-purple-700 font-medium">.csv (UTF-8)</span>
              </div>
              <div className="flex items-center gap-2 p-3 bg-purple-50 rounded-lg border border-purple-200">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <span className="text-sm text-purple-700 font-medium">Pas de limite</span>
              </div>
            </div>
          </div>

          {}
          <div className="flex items-center gap-3 mb-6">
            <Database className="h-6 w-6 text-purple-600 drop-shadow-sm" />
            <h2 className="text-2xl font-bold text-gray-800">Modules d'import</h2>
          </div>

          {}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="transform transition-all duration-300 hover:scale-105">
              <ImportClients />
            </div>
            <div className="transform transition-all duration-300 hover:scale-105">
              <ImportCollaborateurs />
            </div>
            <div className="transform transition-all duration-300 hover:scale-105">
              <ImportNeoexpert />
            </div>
            <div className="transform transition-all duration-300 hover:scale-105">
              <ImportSilae />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

