import { useState } from 'react'
import axios from 'axios'

const ImportCollaborateurs = () => {
  const [file, setFile] = useState(null)
  const [message, setMessage] = useState('')
  const [logUrl, setLogUrl] = useState('')
  const [nullCodes, setNullCodes] = useState([])
  const [errorCount, setErrorCount] = useState(0)

  const handleFileChange = (e) => {
    setFile(e.target.files[0])
    setMessage('')
    setLogUrl('')
    setNullCodes([])
    setErrorCount(0)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!file) return

    const formData = new FormData()
    formData.append('fichier', file)

    try {
      const res = await axios.post("http://192.168.0.22:8000/api/import-collaborateurs", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      })

      const { créés, modifiés, erreurs, log, codes_null } = res.data
      const erreursReelles = erreurs - codes_null.length

      setMessage(`✅ Créés : ${créés} | 📄 Modifiés : ${modifiés} | ❌ Erreurs : ${erreursReelles} | ⚠️ Codes null : ${codes_null.length}`)
      setNullCodes(codes_null)
      setErrorCount(erreursReelles)
      setLogUrl(`http://192.168.0.22:8000/storage/${log}`)
    } catch (err) {
      setMessage("Erreur lors de l'import.")
    }
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-xl mx-auto bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-bold text-center mb-6">Importer des collaborateurs</h2>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <input
            type="file"
            accept=".csv,.xlsx"
            onChange={handleFileChange}
            className="border rounded px-3 py-2"
          />

          <button
            type="submit"
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            Importer
          </button>
        </form>

        {message && (
          <div className="mt-6 p-4 bg-green-100 text-green-900 rounded border border-green-400">
            <p className="font-semibold">Résultat de l'import :</p>
            <p>{message}</p>

            {logUrl && (
              <p className="mt-2">
                <a href={logUrl} download target="_blank" rel="noopener noreferrer" className="underline text-green-800">
                  📄 Télécharger le fichier de log
                </a>
              </p>
            )}

            {nullCodes.length > 0 && (
              <div className="mt-2 text-sm text-yellow-800">
                <p><strong>⚠️ Codes vides détectés :</strong></p>
                <ul className="list-disc pl-5">
                  {nullCodes.map((code, i) => (
                    <li key={i}>{code}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default ImportCollaborateurs
