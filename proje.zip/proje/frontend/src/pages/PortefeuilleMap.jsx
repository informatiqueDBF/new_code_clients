
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'
import CollabMap from '../components/CollabMap'

export default function PortefeuilleMap() {
  const { code } = useParams()
  const [clients, setClients] = useState([])
  const [filteredClient, setFilteredClient] = useState(null)

  useEffect(() => {
    axios.get(`http://192.168.0.22:8000/api/clients-par-collab/${code}`)
      .then(res => setClients(res.data))
      .catch(() => setClients([]))
  }, [code])

  const handleClientClick = (client) => {
    setFilteredClient(client)
  }

  const clearFilter = () => {
    setFilteredClient(null)
  }

  return (
    <div className="flex h-screen">
      {}
      <div className="flex-1">
      <CollabMap />
      </div>
    </div>
  )
}


