import React, { useEffect, useState } from 'react'
import Sidebar from '../components/backoffice/Sidebar'
import axios from 'axios'
import CollaborateurModal from '../components/collaborateurs/CollaborateurModal'
import { Users, Search, Plus, Edit, Trash2, Filter, UserCheck, UserX, Building, Phone, Mail, User, Hash, Shield, X, Eye, Loader2 } from 'lucide-react'

export default function CollaborateursPage() {
  const [collaborateurs, setCollaborateurs] = useState([])
  const [filters, setFilters] = useState({ Code: '', Nom: '', Email: '', Tel: '', Fonction: '', site: '', droit: '', present: '' })
  const [modalOpen, setModalOpen] = useState(false)
  const [selected, setSelected] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const fetchData = () => {
    setLoading(true)
    axios.get('http://192.168.0.22:8000/api/collaborateurs')
      .then(res => {
        setCollaborateurs(res.data)
        setLoading(false)
      })
      .catch(err => {
        setError('Erreur lors du chargement des collaborateurs')
        setLoading(false)
      })
  }

  useEffect(() => {
    fetchData()
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFilters({ ...filters, [name]: value })
  }

  const openModal = (collab = null) => {
    setSelected(collab)
    setModalOpen(true)
  }

  const resetFilters = () => {
    setFilters({ Code: '', Nom: '', Email: '', Tel: '', Fonction: '', site: '', droit: '', present: '' })
  }

  const getPresenceIcon = (present) => {
    const isPresent = present === 1 || present === '1' || String(present) === 'oui' || present === true
    return isPresent ? <UserCheck className="h-4 w-4 text-green-600" /> : <UserX className="h-4 w-4 text-red-600" />
  }

  const getPresenceText = (present) => {
    return present === 1 || present === '1' || String(present) === 'oui' || present === true ? 'Présent' : 'Absent'
  }

  const getPresenceBadge = (present) => {
    const isPresent = present === 1 || present === '1' || String(present) === 'oui' || present === true
    return isPresent 
      ? 'bg-green-100 text-green-800 border-green-300'
      : 'bg-red-100 text-red-800 border-red-300'
  }

  const getDroitText = (droit) => {
    switch (parseInt(droit)) {
      case 0: return 'Aucun accès'
      case 1: return 'Lecture seule'
      case 2: return 'Utilisateur'
      case 3: return 'Administrateur'
      default: return 'Non défini'
    }
  }

  const filtered = collaborateurs.filter(col => {
    return Object.keys(filters).every(key =>
      col[key]?.toString().toLowerCase().includes(filters[key].toLowerCase())
    )
  })

  const totalCollaborateurs = collaborateurs.length
  const presentCollaborateurs = collaborateurs.filter(col => col.present === 1 || col.present === '1' || String(col.present) === 'oui' || col.present === true).length
  const absentCollaborateurs = totalCollaborateurs - presentCollaborateurs
  const uniqueSites = [...new Set(collaborateurs.map(col => col.site).filter(Boolean))].length

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 p-6 ml-64">
        <div className="max-w-full mx-auto px-4">
          {}
          <div className="mb-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-full mb-4 shadow-lg shadow-purple-300">
              <Users className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-purple-800 bg-clip-text text-transparent mb-2 drop-shadow-sm">
              Gestion des Collaborateurs
            </h1>
          </div>

          {}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-xl">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">{totalCollaborateurs}</p>
                  <p className="text-sm text-gray-600">Total collaborateurs</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl">
                  <UserCheck className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">{presentCollaborateurs}</p>
                  <p className="text-sm text-gray-600">Présents</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-red-500 to-pink-600 rounded-xl">
                  <UserX className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">{absentCollaborateurs}</p>
                  <p className="text-sm text-gray-600">Absents</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl">
                  <Building className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">{uniqueSites}</p>
                  <p className="text-sm text-gray-600">Sites</p>
                </div>
              </div>
            </div>
          </div>

          {}
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8 shadow-lg shadow-purple-100">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Filter className="h-6 w-6 text-purple-600 drop-shadow-sm" />
                <h3 className="text-xl font-semibold text-gray-800">Recherche et filtres</h3>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={resetFilters}
                  className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="h-4 w-4" />
                  Réinitialiser
                </button>
                <button 
                  onClick={() => openModal()} 
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 text-white font-medium rounded-lg shadow-lg shadow-purple-200 hover:from-purple-700 hover:via-purple-600 hover:to-purple-800 hover:shadow-xl hover:shadow-purple-300 transition-all duration-300 transform hover:scale-105 active:scale-95"
                >
                  <Plus className="h-5 w-5" />
                  Ajouter un collaborateur
                </button>
              </div>
            </div>
            
            {}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Code</label>
                <div className="relative">
                  <input
                    type="text"
                    name="Code"
                    value={filters.Code}
                    onChange={handleChange}
                    placeholder="Rechercher par code..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  />
                  <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Nom</label>
                <div className="relative">
                  <input
                    type="text"
                    name="Nom"
                    value={filters.Nom}
                    onChange={handleChange}
                    placeholder="Rechercher par nom..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  />
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <div className="relative">
                  <input
                    type="text"
                    name="Email"
                    value={filters.Email}
                    onChange={handleChange}
                    placeholder="Rechercher par email..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  />
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Téléphone</label>
                <div className="relative">
                  <input
                    type="text"
                    name="Tel"
                    value={filters.Tel}
                    onChange={handleChange}
                    placeholder="Rechercher par téléphone..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  />
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Fonction</label>
                <div className="relative">
                  <input
                    type="text"
                    name="Fonction"
                    value={filters.Fonction}
                    onChange={handleChange}
                    placeholder="Rechercher par fonction..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  />
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Site</label>
                <div className="relative">
                  <input
                    type="text"
                    name="site"
                    value={filters.site}
                    onChange={handleChange}
                    placeholder="Rechercher par site..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  />
                  <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Droit</label>
                <div className="relative">
                  <input
                    type="text"
                    name="droit"
                    value={filters.droit}
                    onChange={handleChange}
                    placeholder="Rechercher par droit..."
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  />
                  <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Présence</label>
                <select
                  name="present"
                  value={filters.present}
                  onChange={handleChange}
                  className="w-full py-3 px-4 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                >
                  <option value="">Tous</option>
                  <option value="1">Présent</option>
                  <option value="0">Absent</option>
                </select>
              </div>
            </div>
          </div>

          {}
          {loading ? (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-lg shadow-purple-100">
              <Loader2 className="h-12 w-12 animate-spin text-purple-600 mx-auto mb-4" />
              <p className="text-gray-600">Chargement des collaborateurs...</p>
            </div>
          ) : error ? (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-lg shadow-purple-100">
              <div className="text-red-500 mb-4">❌</div>
              <p className="text-red-600 font-semibold">{error}</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-lg shadow-purple-100">
              <Users className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 text-lg font-medium">Aucun collaborateur trouvé</p>
              <p className="text-gray-500">Essayez de modifier votre recherche</p>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-gray-200 shadow-lg shadow-purple-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full table-auto w-full">
                  <thead className="bg-gradient-to-r from-purple-50 to-indigo-50 border-b border-purple-200">
                    <tr>
                      <th className="px-8 py-5 text-left w-32">
                        <div className="flex items-center gap-2">
                          <Hash className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Code</span>
                        </div>
                      </th>
                      <th className="px-8 py-5 text-left w-48">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Nom</span>
                        </div>
                      </th>
                      <th className="px-8 py-5 text-left w-56">
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Email</span>
                        </div>
                      </th>
                      <th className="px-8 py-5 text-left w-40">
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Téléphone</span>
                        </div>
                      </th>
                      <th className="px-8 py-5 text-left w-40">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Fonction</span>
                        </div>
                      </th>
                      <th className="px-8 py-5 text-left w-36">
                        <div className="flex items-center gap-2">
                          <Building className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Site</span>
                        </div>
                      </th>
                      <th className="px-8 py-5 text-left w-36">
                        <div className="flex items-center gap-2">
                          <Shield className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Droit</span>
                        </div>
                      </th>
                      <th className="px-8 py-5 text-left w-36">
                        <div className="flex items-center gap-2">
                          <UserCheck className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Présence</span>
                        </div>
                      </th>
                      <th className="px-8 py-5 text-center w-48">
                        <span className="font-semibold text-purple-800">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filtered.map((col, index) => (
                      <tr key={col.Code || `collab-${index}`} className="hover:bg-purple-50/50 transition-colors duration-200">
                        <td className="px-8 py-5">
                          <span className="font-mono text-sm bg-gray-100 px-3 py-2 rounded text-gray-700">
                            {col.Code || '-'}
                          </span>
                        </td>
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                              {col.Nom ? col.Nom.charAt(0).toUpperCase() : 'N'}
                            </div>
                            <span className="font-medium text-gray-800 text-base">{col.Nom || '-'}</span>
                          </div>
                        </td>
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-gray-400" />
                            <span className="text-gray-700 text-sm">{col.Email || '-'}</span>
                          </div>
                        </td>
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-2">
                            <Phone className="h-4 w-4 text-gray-400" />
                            <span className="text-gray-700 text-sm">{col.Tel || '-'}</span>
                          </div>
                        </td>
                        <td className="px-8 py-5">
                          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-300">
                            {col.Fonction || '-'}
                          </span>
                        </td>
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-2">
                            <Building className="h-4 w-4 text-gray-400" />
                            <span className="text-gray-700 text-sm">{col.site || '-'}</span>
                          </div>
                        </td>
                        <td className="px-8 py-5">
                          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800 border border-purple-300">
                            {getDroitText(col.droit)}
                          </span>
                        </td>
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-2">
                            {getPresenceIcon(col.present)}
                            <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${getPresenceBadge(col.present)}`}>
                              {getPresenceText(col.present)}
                            </span>
                          </div>
                        </td>
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-3 justify-center">
                            <button 
                              onClick={() => openModal(col)} 
                              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors duration-200"
                            >
                              <Edit className="h-4 w-4" />
                              Modifier
                            </button>
                            <button className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition-colors duration-200">
                              <Trash2 className="h-4 w-4" />
                              Supprimer
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <CollaborateurModal
            isOpen={modalOpen}
            onClose={() => setModalOpen(false)}
            onSaved={fetchData}
            existing={selected}
          />
        </div>
      </div>
    </div>
  )
}
