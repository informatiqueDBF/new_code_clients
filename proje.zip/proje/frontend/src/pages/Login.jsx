import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const { login } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      await login(email, password)
      navigate('/')
    } catch (err) {
      setError("Identifiants invalides")
    }
  }

  return (
    <div
      className="flex h-screen items-center justify-center bg-gray-50 bg-cover bg-center"
      
    >
      <div className="flex w-[800px] rounded-lg shadow bg-white overflow-hidden">
        <div className="w-1/2 p-10">
          <h2 className="text-2xl font-bold mb-2">Connexion</h2>
          <p className="text-sm text-gray-600 mb-6">
            Pour vous connecter veuillez mettre votre email et mot de passe.
          </p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="email"
              placeholder="Saisissez l'adresse e-mail"
              className="w-full border border-gray-300 rounded px-3 py-2"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="**********"
              className="w-full border border-gray-300 rounded px-3 py-2"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button
              type="submit"
              className="bg-purple-600 hover:bg-purple-700 text-white font-semibold w-full py-2 rounded"
            >
              Connexion
            </button>
          </form>
          {error && <p className="text-red-500 mt-4 text-sm">{error}</p>}
          <p className="mt-6 text-sm">
            Une erreur ? <a href="https://dbfaudit.zendesk.com/hc/fr/requests/new" className="text-purple-600 font-medium">Faites une demande Zendesk</a>
          </p>
        </div>

        <div className="w-1/2 bg-purple-600 flex items-center justify-center">
          <img src="/assets/logo.png" alt="DBF" className="w-60 h-auto" />
        </div>
      </div>
    </div>
  )
}

