import React from 'react'
import BackofficeDashboard from '../components/backoffice/BackofficeDashboard'

export default function Backoffice() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-purple-50 via-purple-100 to-indigo-100">
      <BackofficeDashboard />
    </div>
  )
}
