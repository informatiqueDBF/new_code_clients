import { useState } from 'react';
import axios from 'axios';

const ImportClients = () => {
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [logUrl, setLogUrl] = useState(null);
  const [error, setError] = useState('');

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setResult(null);
    setLogUrl(null);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) return;

    const formData = new FormData();
    formData.append('fichier', file);

    try {
        const res = await axios.post("http://192.168.0.22:8000/api/import-clients", formData, {
        
        })  
      setResult(res.data);
      setLogUrl(`http://192.168.0.22:8000/storage/${res.data.log}`);
    } catch (err) {
      setError(err.response?.data?.error || 'Erreur lors de l\'import.');
    }
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="max-w-xl mx-auto bg-white p-6 shadow rounded">
        <h2 className="text-xl font-bold mb-4 text-center">Importer les clients</h2>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <input type="file" onChange={handleFileChange} accept=".csv,.xlsx" />
          <button className="bg-blue-600 text-white py-2 rounded">Importer</button>
        </form>

        {result && (
          <div className="mt-6 bg-green-100 p-4 rounded">
            <p><strong>Créés :</strong> ✅ {result.créés}</p>
            <p><strong>Modifiés :</strong> 🌀 {result.modifiés}</p>
            <p><strong>Erreurs :</strong> ❌ {result.erreurs}</p>
            <p><strong>Codes null :</strong> ⚠️ {result.nulls}</p>
            {logUrl && <a href={logUrl} target="_blank" className="text-blue-600 underline">📄 Télécharger le log</a>}
          </div>
        )}
        {error && <div className="mt-4 text-red-600">{error}</div>}
      </div>
    </div>
  );
};

export default ImportClients;

