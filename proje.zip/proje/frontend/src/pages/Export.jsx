import { useState } from 'react'
import axios from 'axios'
import Sidebar from '../components/backoffice/Sidebar'
import { Download, Loader2, FileSpreadsheet, Filter } from 'lucide-react'

export default function ExportPage() {
  const [filters, setFilters] = useState({
    type: 'clients',
    famille: '',
    outil: '',
  })
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value,
    })
  }

  const handleExport = async () => {
    setLoading(true)
    try {
      const response = await axios.post("http://192.168.0.22:8000/api/export-custom", {
        type: filters.type,
        famille: filters.famille,
        outil: filters.outil || ""
      }, {
        responseType: 'blob'
      })

      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', 'export_custom.xlsx')
      document.body.appendChild(link)
      link.click()
    } catch (error) {
      alert("Erreur lors de l'export")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 p-6 ml-64">
        <div className="max-w-6xl mx-auto">
          {}
          <div className="mb-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-full mb-4 shadow-lg shadow-purple-300">
              <FileSpreadsheet className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-purple-800 bg-clip-text text-transparent mb-2 drop-shadow-sm">
              Export personnalisé
            </h1>
            <p className="text-gray-600 text-lg">Exportez vos données selon vos critères personnalisés</p>
          </div>

          {}
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8 mb-6">
            {}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-6">
                <Filter className="h-5 w-5 text-purple-600 drop-shadow-sm" />
                <h3 className="text-xl font-semibold text-gray-800">Filtres d'export</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Type de données
                  </label>
                  <div className="relative">
                    <select 
                      name="type" 
                      value={filters.type} 
                      onChange={handleChange} 
                      className="w-full border-2 border-gray-200 rounded-xl p-3 bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 focus:shadow-lg focus:shadow-purple-100 transition-all duration-200 appearance-none hover:border-purple-300"
                    >
                      <option value="clients">Clients</option>
                      {}
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                      <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Famille
                  </label>
                  <div className="relative">
                    <select 
                      name="famille" 
                      value={filters.famille} 
                      onChange={handleChange} 
                      className="w-full border-2 border-gray-200 rounded-xl p-3 bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 focus:shadow-lg focus:shadow-purple-100 transition-all duration-200 appearance-none hover:border-purple-300"
                    >
                      <option value="">Toutes les familles</option>
                      <option value="clients sortis">Clients sortis</option>
                      <option value="prospect">Prospects</option>
                      <option value="administrateur judiciaire">Administrateurs judiciaires</option>
                      <option value="douteux">Clients douteux</option>
                      <option value="actifs">Clients actifs (calculés)</option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                      <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Outil utilisé
                  </label>
                  <div className="relative">
                    <select 
                      name="outil" 
                      value={filters.outil} 
                      onChange={handleChange} 
                      className="w-full border-2 border-gray-200 rounded-xl p-3 bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 focus:shadow-lg focus:shadow-purple-100 transition-all duration-200 appearance-none hover:border-purple-300"
                    >
                      <option value="">Choisissez un outil</option>
                      <option value="neoexpert">Neoexpert</option>
                      <option value="silae">Silae</option>
                      <option value="isacompta_autonome">Isacompta autonome</option>
                      <option value="isanet_compta">Isanet compta</option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                      <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {}
            <div className="flex items-center justify-center my-8">
              <div className="h-px bg-gradient-to-r from-transparent via-purple-300 to-transparent w-full"></div>
            </div>

            {}
            <div className="text-center">
              <button
                onClick={handleExport}
                disabled={loading}
                className="group relative inline-flex items-center gap-3 px-8 py-4 text-white font-semibold rounded-xl shadow-xl shadow-purple-200 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 hover:from-purple-700 hover:via-purple-600 hover:to-purple-800 focus:outline-none focus:ring-4 focus:ring-purple-300 disabled:opacity-50 disabled:cursor-not-allowed transform transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-300 active:scale-95"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-300"></div>
                <div className="relative flex items-center gap-3">
                  {loading ? (
                    <Loader2 className="animate-spin h-5 w-5" />
                  ) : (
                    <Download className="h-5 w-5 group-hover:animate-bounce" />
                  )}
                  <span className="text-lg">
                    {loading ? 'Export en cours...' : 'Exporter les données'}
                  </span>
                </div>
              </button>
            </div>
          </div>

          {}
          <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
            <div className="flex items-center justify-center">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-purple-500 rounded-full shadow-sm"></div>
                <span className="text-gray-600">Format Excel (.xlsx)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
