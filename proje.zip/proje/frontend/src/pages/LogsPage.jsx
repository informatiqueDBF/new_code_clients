import React, { useEffect, useState } from 'react'
import Sidebar from '../components/backoffice/Sidebar'
import axios from 'axios'
import { FileText, Search, Download, Clock, HardDrive, FileType, Calendar, Filter, Eye, Loader2, X, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react'

export default function LogsPage() {
  const [logs, setLogs] = useState([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [filters, setFilters] = useState({
    extension: '',
    minSize: '',
    maxSize: '',
    sortBy: 'nom',
    sortOrder: 'asc'
  })

  useEffect(() => {
    axios.get('http://192.168.0.22:8000/api/logs/imports')
      .then(res => {
        setLogs(res.data)
        setLoading(false)
      })
      .catch(err => {
        setError('Erreur lors du chargement des logs')
        setLoading(false)
      })
  }, [])

  const filtered = logs.filter(log => {
    
    const matchesSearch = log.nom.toLowerCase().includes(search.toLowerCase())

    const matchesExtension = !filters.extension || log.extension === filters.extension

    const sizeInKo = log.taille_ko || 0
    const matchesMinSize = !filters.minSize || sizeInKo >= parseFloat(filters.minSize)
    const matchesMaxSize = !filters.maxSize || sizeInKo <= parseFloat(filters.maxSize)
    
    return matchesSearch && matchesExtension && matchesMinSize && matchesMaxSize
  }).sort((a, b) => {
    let valueA, valueB
    
    switch (filters.sortBy) {
      case 'nom':
        valueA = a.nom.toLowerCase()
        valueB = b.nom.toLowerCase()
        break
      case 'taille':
        valueA = a.taille_ko || 0
        valueB = b.taille_ko || 0
        break
      case 'date':
        
        valueA = a.modifie_le ? new Date(a.modifie_le).getTime() : 0
        valueB = b.modifie_le ? new Date(b.modifie_le).getTime() : 0
        break
      case 'extension':
        valueA = a.extension || ''
        valueB = b.extension || ''
        break
      default:
        valueA = a.nom.toLowerCase()
        valueB = b.nom.toLowerCase()
    }

    if (filters.sortBy === 'date' || filters.sortBy === 'taille') {
      if (filters.sortOrder === 'asc') {
        return valueA - valueB
      } else {
        return valueB - valueA
      }
    }

    if (filters.sortOrder === 'asc') {
      return valueA > valueB ? 1 : -1
    } else {
      return valueA < valueB ? 1 : -1
    }
  })

  const uniqueExtensions = [...new Set(logs.map(log => log.extension).filter(Boolean))]

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }))
  }

  const resetFilters = () => {
    setSearch('')
    setFilters({
      extension: '',
      minSize: '',
      maxSize: '',
      sortBy: 'nom',
      sortOrder: 'asc'
    })
  }

  const formatFileSize = (sizeKo) => {
    if (sizeKo < 1024) return `${sizeKo} Ko`
    return `${(sizeKo / 1024).toFixed(1)} Mo`
  }

  const getFileTypeIcon = (extension) => {
    switch (extension?.toLowerCase()) {
      case '.xlsx':
      case '.xls':
        return '📊'
      case '.csv':
        return '📄'
      case '.txt':
        return '📝'
      default:
        return '📁'
    }
  }

  const getExtensionColor = (extension) => {
    switch (extension?.toLowerCase()) {
      case '.xlsx':
      case '.xls':
        return 'bg-green-100 text-green-800 border-green-300'
      case '.csv':
        return 'bg-blue-100 text-blue-800 border-blue-300'
      case '.txt':
        return 'bg-gray-100 text-gray-800 border-gray-300'
      default:
        return 'bg-purple-100 text-purple-800 border-purple-300'
    }
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 p-6 ml-64">
        <div className="max-w-7xl mx-auto">
          {}
          <div className="mb-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 rounded-full mb-4 shadow-lg shadow-purple-300">
              <FileText className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-purple-800 bg-clip-text text-transparent mb-2 drop-shadow-sm">
              Logs d'importation
            </h1>
          </div>

          {}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl">
                  <FileText className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">{logs.length}</p>
                  <p className="text-sm text-gray-600">Fichiers de logs</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-xl">
                  <HardDrive className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">
                    {formatFileSize(logs.reduce((acc, log) => acc + (log.taille_ko || 0), 0))}
                  </p>
                  <p className="text-sm text-gray-600">Taille totale</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-lg shadow-purple-100">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl">
                  <Filter className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">{filtered.length}</p>
                  <p className="text-sm text-gray-600">Fichiers filtrés</p>
                </div>
              </div>
            </div>
          </div>

          {}
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8 shadow-lg shadow-purple-100">
            <div className="flex items-center gap-3 mb-6">
              <Search className="h-6 w-6 text-purple-600 drop-shadow-sm" />
              <h3 className="text-xl font-semibold text-gray-800">Recherche et filtres</h3>
              <button
                onClick={resetFilters}
                className="ml-auto flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="h-4 w-4" />
                Réinitialiser
              </button>
            </div>
            
            {}
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Rechercher par nom</label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Nom du fichier..."
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              {}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Type de fichier</label>
                <select
                  value={filters.extension}
                  onChange={e => handleFilterChange('extension', e.target.value)}
                  className="w-full py-3 px-4 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                >
                  <option value="">Tous les types</option>
                  {uniqueExtensions.map(ext => (
                    <option key={ext} value={ext}>{ext}</option>
                  ))}
                </select>
              </div>

              {}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Taille min (Ko)</label>
                <input
                  type="number"
                  placeholder="0"
                  value={filters.minSize}
                  onChange={e => handleFilterChange('minSize', e.target.value)}
                  className="w-full py-3 px-4 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                />
              </div>

              {}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Taille max (Ko)</label>
                <input
                  type="number"
                  placeholder="∞"
                  value={filters.maxSize}
                  onChange={e => handleFilterChange('maxSize', e.target.value)}
                  className="w-full py-3 px-4 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                />
              </div>
            </div>

            {}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Trier par</label>
                <select
                  value={filters.sortBy}
                  onChange={e => handleFilterChange('sortBy', e.target.value)}
                  className="w-full py-3 px-4 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                >
                  <option value="nom">Nom</option>
                  <option value="taille">Taille</option>
                  <option value="date">Date de modification</option>
                  <option value="extension">Type de fichier</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Ordre</label>
                <select
                  value={filters.sortOrder}
                  onChange={e => handleFilterChange('sortOrder', e.target.value)}
                  className="w-full py-3 px-4 border-2 border-gray-200 rounded-xl bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition-all duration-200"
                >
                  <option value="asc">Croissant</option>
                  <option value="desc">Décroissant</option>
                </select>
              </div>
            </div>

            {}
            {(search || filters.extension || filters.minSize || filters.maxSize || filters.sortBy !== 'nom') && (
              <div className="mt-4 p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-sm text-purple-800 font-medium mb-2">Filtres actifs :</p>
                <div className="flex flex-wrap gap-2">
                  {search && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-700 rounded-md text-xs">
                      Nom: "{search}"
                    </span>
                  )}
                  {filters.extension && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-700 rounded-md text-xs">
                      Type: {filters.extension}
                    </span>
                  )}
                  {filters.minSize && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-700 rounded-md text-xs">
                      Min: {filters.minSize} Ko
                    </span>
                  )}
                  {filters.maxSize && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-700 rounded-md text-xs">
                      Max: {filters.maxSize} Ko
                    </span>
                  )}
                  {filters.sortBy !== 'nom' && (
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-700 rounded-md text-xs">
                      Tri: {filters.sortBy} ({filters.sortOrder === 'asc' ? 'croissant' : 'décroissant'})
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {}
          {loading ? (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-lg shadow-purple-100">
              <Loader2 className="h-12 w-12 animate-spin text-purple-600 mx-auto mb-4" />
              <p className="text-gray-600">Chargement des logs...</p>
            </div>
          ) : error ? (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-lg shadow-purple-100">
              <div className="text-red-500 mb-4">❌</div>
              <p className="text-red-600 font-semibold">{error}</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-lg shadow-purple-100">
              <FileText className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 text-lg font-medium">Aucun log trouvé</p>
              <p className="text-gray-500">Essayez de modifier votre recherche</p>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-gray-200 shadow-lg shadow-purple-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead className="bg-gradient-to-r from-purple-50 to-indigo-50 border-b border-purple-200">
                    <tr>
                      <th className="px-6 py-4 text-left">
                        <button
                          onClick={() => {
                            const newOrder = filters.sortBy === 'nom' && filters.sortOrder === 'asc' ? 'desc' : 'asc'
                            handleFilterChange('sortBy', 'nom')
                            handleFilterChange('sortOrder', newOrder)
                          }}
                          className="flex items-center gap-2 hover:text-purple-900 transition-colors"
                        >
                          <FileText className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Nom du fichier</span>
                          {filters.sortBy === 'nom' && (
                            filters.sortOrder === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                          )}
                        </button>
                      </th>
                      <th className="px-6 py-4 text-left">
                        <button
                          onClick={() => {
                            const newOrder = filters.sortBy === 'taille' && filters.sortOrder === 'asc' ? 'desc' : 'asc'
                            handleFilterChange('sortBy', 'taille')
                            handleFilterChange('sortOrder', newOrder)
                          }}
                          className="flex items-center gap-2 hover:text-purple-900 transition-colors"
                        >
                          <HardDrive className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Taille</span>
                          {filters.sortBy === 'taille' && (
                            filters.sortOrder === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                          )}
                        </button>
                      </th>
                      <th className="px-6 py-4 text-left">
                        <button
                          onClick={() => {
                            const newOrder = filters.sortBy === 'date' && filters.sortOrder === 'asc' ? 'desc' : 'asc'
                            handleFilterChange('sortBy', 'date')
                            handleFilterChange('sortOrder', newOrder)
                          }}
                          className="flex items-center gap-2 hover:text-purple-900 transition-colors"
                        >
                          <Calendar className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Modifié le</span>
                          {filters.sortBy === 'date' && (
                            filters.sortOrder === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                          )}
                        </button>
                      </th>
                      <th className="px-6 py-4 text-left">
                        <button
                          onClick={() => {
                            const newOrder = filters.sortBy === 'extension' && filters.sortOrder === 'asc' ? 'desc' : 'asc'
                            handleFilterChange('sortBy', 'extension')
                            handleFilterChange('sortOrder', newOrder)
                          }}
                          className="flex items-center gap-2 hover:text-purple-900 transition-colors"
                        >
                          <FileType className="h-4 w-4 text-purple-600" />
                          <span className="font-semibold text-purple-800">Type</span>
                          {filters.sortBy === 'extension' && (
                            filters.sortOrder === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                          )}
                        </button>
                      </th>
                      <th className="px-6 py-4 text-center">
                        <span className="font-semibold text-purple-800">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filtered.map((log, i) => (
                      <tr key={i} className="hover:bg-purple-50/50 transition-colors duration-200">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <span className="text-lg">{getFileTypeIcon(log.extension)}</span>
                            <div>
                              <p className="font-medium text-gray-800">{log.nom}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-gray-700 font-medium">{formatFileSize(log.taille_ko)}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-gray-400" />
                            <span className="text-gray-700">{log.modifie_le}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${getExtensionColor(log.extension)}`}>
                            {log.extension}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <a
                            href={`http://192.168.0.22:8000/api/logs/download/${log.nom}`}
                            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-700 text-white font-medium rounded-lg shadow-lg shadow-purple-200 hover:from-purple-700 hover:via-purple-600 hover:to-purple-800 hover:shadow-xl hover:shadow-purple-300 transition-all duration-300 transform hover:scale-105 active:scale-95"
                            download
                          >
                            <Download className="h-4 w-4" />
                            Télécharger
                          </a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

