import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Users, TrendingUp, AlertTriangle, UserX, Gavel, Plus, BarChart3, FileText, Settings } from 'lucide-react'

import Headbar from '../components/dashboard/Headbar'
import StatCard from '../components/dashboard/StatCard'
import ClientFilters from '../components/dashboard/ClientFilters'
import ClientSummary from '../components/dashboard/ClientSummary'
import ClientFiche from '../components/dashboard/ClientFiche'
import ClientInfos from '../components/dashboard/ClientInfos'
import ClientPortefeuille from '../components/dashboard/ClientPortefeuille'
import ClientOutils from '../components/dashboard/ClientOutils'
import PostItBoard from '../components/dashboard/PostItBoard'

export default function ClientDashboard() {
  const [showPortefeuille, setShowPortefeuille] = useState(true)
  const [selectedClient, setSelectedClient] = useState(null)
  const [createNoteTrigger, setCreateNoteTrigger] = useState(false)
  const [stats, setStats] = useState({
    actifs: 0,
    douteux: 0,
    prospects: 0,
    sortis: 0,
    admin_judiciaire: 0,
  })

  const [nom, setNom] = useState('')
  const [code, setCode] = useState('')

  const handleCreatePostIt = async () => {
    if (!selectedClient) return
    
    try {
      const res = await axios.post(`http://192.168.0.22:8000/api/clients/${selectedClient.Code}/notes`, {
        position_x: -300, 
        position_y: -300, 
        couleur: '#FFFB7D',
        contenu: ''
      })
      console.log('Post-it créé:', res.data)
      
      setCreateNoteTrigger(prev => !prev)
    } catch (error) {
      console.error('Erreur lors de la création du post-it:', error)
      console.error('Détails de l\'erreur:', error.response?.data)
    }
  }

  const handleSelectClient = async (client) => {
    try {
      const res = await axios.get(`http://192.168.0.22:8000/api/clients/${client.Code}`)
      setSelectedClient(res.data)
      setNom(client.Nom_complet || '')
      setCode(client.Code || '')
    } catch {
      setSelectedClient(null)
    }
  }

  useEffect(() => {
    axios.get('http://192.168.0.22:8000/api/stats/clients')
      .then(res => setStats(res.data))
      .catch(err => console.error('Erreur chargement stats', err))
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-purple-50">
      <div className="max-w-screen-1xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {}
        <div className="mb-8">
          <Headbar />
        </div>

        {}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-8">
          <StatCard 
            label="Clients actifs" 
            value={stats.actifs} 
            icon={Users}
            color="from-emerald-500 to-teal-600"
            bgColor="bg-emerald-50"
            textColor="text-emerald-700"
          />
          <StatCard 
            label="Clients douteux" 
            value={stats.douteux} 
            icon={AlertTriangle}
            color="from-orange-500 to-red-600"
            bgColor="bg-orange-50"
            textColor="text-orange-700"
          />
          <StatCard 
            label="Prospects" 
            value={stats.prospects} 
            icon={TrendingUp}
            color="from-blue-500 to-cyan-600"
            bgColor="bg-blue-50"
            textColor="text-blue-700"
          />
          <StatCard 
            label="Clients sortis" 
            value={stats.sortis} 
            icon={UserX}
            color="from-gray-500 to-slate-600"
            bgColor="bg-gray-50"
            textColor="text-gray-700"
          />
          <StatCard 
            label="Administrateurs judiciaires" 
            value={stats.admin_judiciaire} 
            icon={Gavel}
            color="from-purple-500 to-pink-600"
            bgColor="bg-purple-50"
            textColor="text-purple-700"
          />
        </div>

        {}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 mb-8">
          <div className="xl:col-span-9">
            <div className="bg-white rounded-2xl border border-gray-200 shadow-lg shadow-purple-100 p-6">
              <div className="flex items-center gap-3 mb-6">
                <FileText className="h-6 w-6 text-purple-600" />
                <h2 className="text-xl font-bold text-gray-800">Filtres et Recherche</h2>
              </div>
              <ClientFilters
                showPortefeuille={showPortefeuille}
                setShowPortefeuille={setShowPortefeuille}
                setSelectedClient={setSelectedClient}
                nom={nom}
                code={code}
                setNom={setNom}
                setCode={setCode}
              />
            </div>
          </div>
          {showPortefeuille && (
            <div className="xl:col-span-3">
              <div className="bg-white rounded-2xl border border-gray-200 shadow-lg shadow-purple-100 p-6">
                <div className="flex items-center gap-3 mb-6">
                  <BarChart3 className="h-6 w-6 text-purple-600" />
                  <h2 className="text-xl font-bold text-gray-800">Résumé</h2>
                </div>
                <ClientSummary />
              </div>
            </div>
          )}
        </div>

        {}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 mb-8">
          <div className="xl:col-span-6">
            <div className="bg-white rounded-2xl border border-gray-200 shadow-lg shadow-purple-100 p-6 h-full">
              <div className="flex items-center gap-3 mb-6">
                <Users className="h-6 w-6 text-purple-600" />
                <h2 className="text-xl font-bold text-gray-800">Fiche Client</h2>
              </div>
              <ClientFiche client={selectedClient} />
            </div>
          </div>
          <div className="xl:col-span-3">
            <div className="bg-white rounded-2xl border border-gray-200 shadow-lg shadow-purple-100 p-6 h-full">
              <div className="flex items-center gap-3 mb-6">
                <FileText className="h-6 w-6 text-purple-600" />
                <h2 className="text-xl font-bold text-gray-800">Informations</h2>
              </div>
              <ClientInfos client={selectedClient} />
            </div>
          </div>
          {showPortefeuille && (
            <div className="xl:col-span-3">
              <div className="bg-white rounded-2xl border border-gray-200 shadow-lg shadow-purple-100 p-6 h-full">
                <div className="flex items-center gap-3 mb-6">
                  <TrendingUp className="h-6 w-6 text-purple-600" />
                  <h2 className="text-xl font-bold text-gray-800">Portefeuille</h2>
                </div>
                <ClientPortefeuille
                  onSelectClient={handleSelectClient}
                  selectedClient={selectedClient}
                  setSearchNom={setNom}
                  setSearchCode={setCode}
                />
              </div>
            </div>
          )}
        </div>

        {}
        <div className="mb-8">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-lg shadow-purple-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <Settings className="h-6 w-6 text-purple-600" />
              <h2 className="text-xl font-bold text-gray-800">Outils Client</h2>
            </div>
            <ClientOutils client={selectedClient} />
          </div>
        </div>

        {}
        {selectedClient && (
          <PostItBoard clientCode={selectedClient.Code} key={createNoteTrigger} />
        )}

        {}
        {selectedClient && (
          <button
            onClick={handleCreatePostIt}
            className="fixed bottom-8 right-8 bg-gradient-to-r from-purple-600 to-purple-700 text-white w-16 h-16 rounded-2xl shadow-2xl shadow-purple-300 hover:shadow-purple-400 hover:scale-105 transition-all duration-300 flex items-center justify-center z-50 group"
            title="Ajouter un post-it"
          >
            <Plus className="h-8 w-8 group-hover:rotate-90 transition-transform duration-300" />
          </button>
        )}

      </div>
    </div>
  )
}


