import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import Login from './pages/Login'

import ClientDashboard from './pages/ClientDashboard'
import ImportPage from './pages/Import'
import Backoffice from './pages/Backoffice'
import CollaborateursPage from './pages/Collaborateurs'
import ExportPage from './pages/Export'
import PortefeuilleMap from './pages/PortefeuilleMap'
import LogsPage from './pages/LogsPage'

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<ProtectedRoute><ClientDashboard /></ProtectedRoute>} />
          <Route path="/import" element={<ProtectedRoute><ImportPage /></ProtectedRoute>} />
          <Route path="/logs" element={<ProtectedRoute><LogsPage /></ProtectedRoute>} />
          <Route path="/collaborateurs" element={<ProtectedRoute><CollaborateursPage /></ProtectedRoute>} />
          <Route path="/backoffice" element={<ProtectedRoute><Backoffice /></ProtectedRoute>} />
          <Route path="/export" element={<ProtectedRoute><ExportPage /></ProtectedRoute>} />
          <Route path="/portefeuille/:code" element={<ProtectedRoute><PortefeuilleMap /></ProtectedRoute>} />
        </Routes>
      </Router>
    </AuthProvider>
  )
}

export default App
