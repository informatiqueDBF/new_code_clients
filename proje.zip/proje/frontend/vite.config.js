import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 4040,
    proxy: {
      '/api': {
        target: 'http://192.168.0.22:8000',
        changeOrigin: true,
        secure: false,
      },
    },
  },
  
})
