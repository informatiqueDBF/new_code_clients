<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('notes', function (Blueprint $table) {
            $table->id();
            $table->string('client_code'); // lié au Code du client
            $table->text('contenu')->nullable();
            $table->string('couleur')->default('#FFFB7D');
            $table->string('fichier')->nullable();
            $table->integer('position_x')->default(300);
            $table->integer('position_y')->default(300);
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('notes');
    }
};
