<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('collaborateurs', function (Blueprint $table) {
            $table->string('Code', 10)->primary();
            $table->string('Nom')->nullable();
            $table->string('Email')->nullable();
            $table->string('Tel', 50)->nullable();
            $table->string('Fonction')->nullable();
            $table->string('site')->nullable();
            $table->string('present', 10)->nullable();
            $table->integer('droit')->default(0);
            $table->integer('exception')->default(0);
            $table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('collaborateurs');
    }
};
