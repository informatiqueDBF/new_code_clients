<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->string('Code')->primary();
            $table->string('Nom_complet')->nullable();
            $table->string('Qualification')->nullable();
            $table->string('Famille')->nullable();
            $table->string('Nature')->nullable();
            $table->string('Titre')->nullable();
            $table->string('Nom_denomination')->nullable();
            $table->string('Nom_commercial')->nullable();
            $table->string('Forme_juridique')->nullable();
            $table->string('Tel_fax')->nullable();
            $table->string('Tel')->nullable();
            $table->string('Email')->nullable();
            $table->string('Date_creation', 30)->nullable();
            $table->string('Tva')->nullable();
            $table->string('Siret')->nullable();
            $table->string('Ape_code', 50)->nullable();
            $table->string('Ape_libelle')->nullable();
            $table->string('Nafu_code', 50)->nullable();
            $table->string('Nafu_libelle')->nullable();
            $table->string('Activite_exercer')->nullable();
            $table->string('Activite')->nullable();
            $table->string('Activite_libelle')->nullable();
            $table->string('Rcs')->nullable();
            $table->string('numero')->nullable();
            $table->string('Responsable_Code', 50)->nullable();
            $table->string('Chef_de_mission_Code', 5)->nullable();
            $table->string('Collaborateur_Code', 10)->nullable();
            $table->string('departement')->nullable();
            $table->string('departement_libelle')->nullable();
            $table->string('adresse')->nullable();
            $table->string('adresse_1')->nullable();
            $table->string('adresse_2')->nullable();
            $table->string('adresse_3')->nullable();
            $table->string('code_postal')->nullable();
            $table->string('commune')->nullable();
            $table->timestamps();
        });        
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('clients');
    }
};
