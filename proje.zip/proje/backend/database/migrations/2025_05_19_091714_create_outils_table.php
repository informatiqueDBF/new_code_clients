<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('outils', function (Blueprint $table) {
            $table->id();
            $table->string('client_code');
            $table->string('isacompta_autonome')->nullable();
            $table->string('isanet_compta')->nullable();
            $table->string('isacompta_collaboratif')->nullable();
            $table->string('autre_logiciel')->nullable();
            $table->string('neant')->nullable();
            $table->string('neoexpert')->nullable();
            $table->string('silae')->nullable();
            $table->timestamps();
        });
    }
    
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('outils');
    }
};
