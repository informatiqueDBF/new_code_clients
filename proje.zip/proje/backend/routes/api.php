<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ImportClientController;
use App\Http\Controllers\ImportCollaborateurController;
use App\Http\Controllers\BackofficeController;
use App\Http\Controllers\CollaborateurController;
use App\Http\Controllers\ClientStatController;
use App\Http\Controllers\ClientSearchController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\LdapAuthController;
use App\Http\Controllers\ClientStatMeController;
use App\Http\Controllers\ImportNeoexpertController;
use App\Http\Controllers\ImportSilaeController;
use App\Http\Controllers\OutilController;
use App\Http\Controllers\TemplateController;
use App\Http\Controllers\ExportCustomController;
use App\Exports\ClientsParAnExport;
use App\Exports\CollaborateursParSiteExport;
use App\Exports\OutilsExport;
use App\Exports\ClientsParDepartementExport;
use App\Exports\ClientsParApeExport;
use App\Exports\ClientsParFormeJuridiqueExport;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Controllers\NoteController;
use App\Http\Controllers\LogController;

// Authentification LDAP
Route::middleware([
    \Illuminate\Session\Middleware\StartSession::class,
    \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
    \Illuminate\View\Middleware\ShareErrorsFromSession::class
])->group(function () {
    Route::post('/login', [LdapAuthController::class, 'login']);
    Route::get('/me', [LdapAuthController::class, 'me']);
    Route::post('/logout', [LdapAuthController::class, 'logout']);
});

// Dashboard & stats
Route::get('/client-stats/{code}', [ClientStatMeController::class, 'index']);
Route::get('/stats/clients', [ClientStatController::class, 'index']);
Route::get('/backoffice/graphs', [BackofficeController::class, 'stats']);

// Clients & outils
Route::get('/clients/search', [ClientSearchController::class, 'filter']);
Route::get('/clients/{code}', [ClientController::class, 'show']);
Route::get('/outils/{client_code}', [OutilController::class, 'show']);
Route::get('/clients-par-collab/{code}', [ClientController::class, 'portefeuille']);

//maps
Route::get('/geocode', [ClientController::class, 'geocode']);

//notes
Route::get('/clients/{code}/notes', [NoteController::class, 'index']);
Route::post('/clients/{code}/notes', [NoteController::class, 'store']);
Route::post('/notes/{id}/upload', [NoteController::class, 'upload']);
Route::delete('/notes/{note}', [NoteController::class, 'destroy']);
Route::put('/notes/{note}', [NoteController::class, 'update']);


//logs
Route::get('/logs/imports', [\App\Http\Controllers\LogController::class, 'index']);
Route::get('/logs/download/{filename}', [\App\Http\Controllers\LogController::class, 'download']);


// Collaborateurs
Route::get('/collaborateurs', [CollaborateurController::class, 'index']);
Route::post('/collaborateurs', [CollaborateurController::class, 'store']);
Route::get('/collaborateurs/{code}', [CollaborateurController::class, 'show']);
Route::put('/collaborateurs/{collaborateur}', [CollaborateurController::class, 'update']);
Route::delete('/collaborateurs/{collaborateur}', [CollaborateurController::class, 'destroy']);

// Importation fichiers
Route::post('/import-clients', [ImportClientController::class, 'import']);
Route::post('/import-collaborateurs', [ImportCollaborateurController::class, 'import']);
Route::post('/import-neoexpert', [ImportNeoexpertController::class, 'import']);
Route::post('/import-silae', [ImportSilaeController::class, 'import']);

// Exportation fichiers
Route::get('/export/clients-par-an', fn() => Excel::download(new ClientsParAnExport, 'clients_par_an.xlsx'));
Route::get('/export/collaborateurs-par-site', fn() => Excel::download(new CollaborateursParSiteExport, 'collaborateurs_par_site.xlsx'));
Route::get('/export/outils', fn() => Excel::download(new OutilsExport, 'outils_clients.xlsx'));
Route::get('/export/clients-par-departement', fn() => Excel::download(new ClientsParDepartementExport, 'clients_par_departement.xlsx'));
Route::get('/export/clients-par-ape', fn() => Excel::download(new ClientsParApeExport, 'clients_par_ape.xlsx'));
Route::get('/export/clients-par-forme-juridique', fn() => Excel::download(new ClientsParFormeJuridiqueExport, 'clients_par_forme_juridique.xlsx'));
Route::post('/export-custom', [ExportCustomController::class, 'export']);

// Templates Excel
Route::get('/template/clients', [TemplateController::class, 'clients']);
Route::get('/template/collaborateurs', [TemplateController::class, 'collaborateurs']);
Route::get('/template/neoexpert', [TemplateController::class, 'neoexpert']);
Route::get('/template/silae', [TemplateController::class, 'silae']);

// Page par défaut
Route::get('/', fn() => view('welcome'));
