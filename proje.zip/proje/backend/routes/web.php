<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ImportClientController;
use App\Http\Controllers\ImportCollaborateurController;
// use App\Http\Controllers\LdapAuthController;

// Route::post('/login', [LdapAuthController::class, 'login']);
// Route::get('/me', [LdapAuthController::class, 'me']);
// Route::post('/logout', [LdapAuthController::class, 'logout']);

Route::get('/import', [ImportClientController::class, 'showForm']);
Route::post('/import', [ImportClientController::class, 'import']);
Route::post('/import-collaborateurs', [ImportCollaborateurController::class, 'import']);

Route::get('/', function () {
    return view('welcome');
});
