<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use App\Imports\ClientImport;
use App\Exports\ClientImportLogExport;
use Maatwebsite\Excel\Facades\Excel;

class ImportClientController extends Controller
{
    public function import(Request $request)
    {
        set_time_limit(300);

        $request->validate([
            'fichier' => 'required|file|max:20480',
        ]);
        if (!$request->hasFile('fichier')) {
            return response()->json(['error' => 'Aucun fichier reçu côté serveur.'], 422);
        }
        
        if (!$request->file('fichier')->isValid()) {
            return response()->json(['error' => 'Fichier invalide ou corrompu.'], 422);
        }
        
        \Log::info('Nom du fichier reçu : ' . $request->file('fichier')->getClientOriginalName());
        \Log::info('Extension détectée : ' . $request->file('fichier')->getClientOriginalExtension());
        \Log::info('Mime type : ' . $request->file('fichier')->getMimeType());
        
        try {
            $import = new ClientImport();
            $import->import($request->file('fichier'));

            $folder = storage_path('app/import_logs');
            if (!File::exists($folder)) {
                File::makeDirectory($folder, 0755, true);
            }

            $timestamp = now()->format('Y-m-d_H-i-s');
            $logFilename = "import_logs/client_import_" . uniqid() . "_{$timestamp}.xlsx";

            if (!empty($import->logs)) {
                Excel::store(
                    new ClientImportLogExport($import->logs),
                    $logFilename,
                    'public'
                );
            }

            return response()->json([
                'message' => 'Importation réussie.',
                'créés' => $import->created,
                'modifiés' => $import->updated,
                'erreurs' => $import->errors,
                'nulls' => $import->nulls,
                'codes_null' => $import->nullCodes,
                'log' => !empty($import->logs) ? $logFilename : null,
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'error' => 'Erreur lors de l\'import : ' . $e->getMessage()
            ], 500);
        }
    }
}
