<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Collaborateur;

class LdapAuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $email = $request->email;
        $password = $request->password;

        $ldapserver = "ldap://srv-dom-04.groupedbf.local";
        $ldapdomain = "groupedbf.local";
        $ldapport = 389;
        $ldapbasedn = "dc=groupedbf,dc=local";

        $ldapconn = ldap_connect($ldapserver, $ldapport);
        if (!$ldapconn) {
            return response()->json(['message' => 'Connexion LDAP impossible'], 500);
        }

        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($ldapconn, LDAP_OPT_REFERRALS, 0);

        $username = explode('@', $email)[0];
        
        $ldapuser1 = "$username@$ldapdomain";       
        $ldapuser2 = "groupedbf\\$username";         
        $ldapuser3 = $email;                          
        $ldapuser4 = $username;                     
        $ldapuser5 = "GROUPEDBF\\$username";      

        $bind = @ldap_bind($ldapconn, $ldapuser1, $password)
              ?: @ldap_bind($ldapconn, $ldapuser2, $password)
              ?: @ldap_bind($ldapconn, $ldapuser3, $password)
              ?: @ldap_bind($ldapconn, $ldapuser4, $password)
              ?: @ldap_bind($ldapconn, $ldapuser5, $password);

        if (!$bind) {
            ldap_close($ldapconn);
            return response()->json(['message' => 'Identifiants invalides'], 401);
        }

        $filter = "(mail=" . ldap_escape($email, '', LDAP_ESCAPE_FILTER) . ")";
        $result = ldap_search($ldapconn, $ldapbasedn, $filter);
        $entries = ldap_get_entries($ldapconn, $result);
        ldap_close($ldapconn);

        if ($entries['count'] === 0) {
            return response()->json(['message' => 'Utilisateur introuvable dans LDAP'], 404);
        }

        $collaborateur = Collaborateur::where('Email', $email)->first();

        if (!$collaborateur) {
            return response()->json(['message' => 'Accès refusé (non présent en BDD)'], 403);
        }

        Session::put('user', [
            'Code' => $collaborateur->Code,
            'Nom' => $collaborateur->Nom,
            'Email' => $collaborateur->Email,
            'Tel' => $collaborateur->Tel,
            'Fonction' => $collaborateur->Fonction,
            'Site' => $collaborateur->site,
            'Present' => $collaborateur->present,
            'Droit' => $collaborateur->droit,
            'Exception' => $collaborateur->exception
        ]);

        return response()->json([
            'message' => 'Connexion réussie',
            'user' => Session::get('user')
        ]);
        
    }

    public function me()
    {
        $user = Session::get('user');
        if (!$user) {
            return response()->json(['message' => 'Non connecté'], 401);
        }
        
        // Récupérer les données fraîches de la base de données
        $collaborateur = Collaborateur::where('Email', $user['Email'])->first();
        
        if (!$collaborateur) {
            // Si l'utilisateur n'existe plus en base, déconnecter
            Session::forget('user');
            return response()->json(['message' => 'Utilisateur introuvable'], 401);
        }
        
        // Mettre à jour les données dans la session avec les données fraîches
        $freshUser = [
            'Code' => $collaborateur->Code,
            'Nom' => $collaborateur->Nom,
            'Email' => $collaborateur->Email,
            'Tel' => $collaborateur->Tel,
            'Fonction' => $collaborateur->Fonction,
            'Site' => $collaborateur->site,
            'Present' => $collaborateur->present,
            'Droit' => $collaborateur->droit,
            'Exception' => $collaborateur->exception
        ];
        
        Session::put('user', $freshUser);
        
        return response()->json(['user' => $freshUser]);
    }

    public function logout()
    {
        Session::forget('user');
        return response()->json(['message' => 'Déconnexion réussie']);
    }
}
