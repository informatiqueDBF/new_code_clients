<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClientSearchController extends Controller
{
    public function filter(Request $request)
    {
        $query = DB::table('clients');
    
        if (!$request->boolean('client_sortis')) {
            $query->whereNotIn('Famille', ['Clients sortis', 'clients sortis']);
        }
    
        if ($request->filled('nom')) {
            $query->where('Nom_complet', 'like', '%' . $request->input('nom') . '%');
        }
    
        if ($request->filled('code')) {
            $query->where('Code', 'like', '%' . $request->input('code') . '%');
        }
    
        return response()->json($query->limit(100)->get());
    }    
}
