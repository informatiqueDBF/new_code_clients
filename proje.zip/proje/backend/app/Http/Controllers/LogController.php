<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;

class LogController extends Controller
{
    public function index()
    {
        $files = File::files(storage_path('app/public/import_logs'));
        $data = collect($files)->map(function ($file) {
            return [
                'nom' => $file->getFilename(),
                'taille_ko' => round($file->getSize() / 1024, 1),
                'modifie_le' => date('d/m/Y H:i', $file->getMTime()),
                'extension' => $file->getExtension(),
            ];
        })->sortByDesc('modifie_le')->values();

        return response()->json($data);
    }

    public function download($filename)
    {
        $path = storage_path("app/public/import_logs/{$filename}");

        if (!file_exists($path)) {
            return response()->json(['error' => 'Fichier non trouvé.'], 404);
        }

        return response()->download($path);
    }

}
