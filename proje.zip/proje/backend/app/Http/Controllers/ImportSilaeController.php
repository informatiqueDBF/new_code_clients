<?php

namespace App\Http\Controllers;

use App\Imports\SilaeImport;
use App\Exports\ClientImportLogExport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Str;

class ImportSilaeController extends Controller
{
    public function import(Request $request)
    {
        // $request->validate([
        //     'fichier' => 'required|file|mimes:xlsx,csv,xls',
        // ]);

        $import = new SilaeImport();
        Excel::import($import, $request->file('fichier'));

        $logFilename = 'silae_' . Str::random(8) . '.xlsx';

        if (!empty($import->logs)) {
            Excel::store(
                new ClientImportLogExport($import->logs),
                $logFilename,
                'public'
            );
        }

        return response()->json([
            'créés' => $import->created,
            'modifiés' => $import->updated,
            'erreurs' => $import->errors,
            'codes_null' => $import->nullCodes,
            'log' => $logFilename,
        ]);
    }
}
