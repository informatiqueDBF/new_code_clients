<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Note; // ← AJOUTE CECI

class NoteController extends Controller
{
    public function index($code) {
        return Note::where('client_code', $code)->get();
    }

    public function store(Request $request, $code)
    {
        $data = $request->validate([
            'contenu' => 'nullable|string',
            'couleur' => 'nullable|string',
            'position_x' => 'required|integer',
            'position_y' => 'required|integer',
            'fichier' => 'nullable|file|max:10240'
        ]);

        $data['client_code'] = $code;

        if ($request->hasFile('fichier')) {
            $data['fichier'] = $request->file('fichier')->store('notes', 'public');
        }

        return Note::create($data);
    }

    public function update(Request $request, Note $note)
    {
        $note->update($request->only(['contenu', 'couleur', 'position_x', 'position_y']));
        return $note;
    }

    public function upload(Request $request, $id)
    {
        $note = Note::findOrFail($id);
    
        if ($request->hasFile('fichier')) {
            $path = $request->file('fichier')->store('notes', 'public');
            $note->update(['fichier' => $path]);
            return response()->json(['path' => $path]);
        }
    
        return response()->json(['error' => 'Aucun fichier'], 400);
    }
    

    public function destroy(Note $note)
    {
        $note->delete();
        return response()->json(['deleted' => true]);
    }
}
