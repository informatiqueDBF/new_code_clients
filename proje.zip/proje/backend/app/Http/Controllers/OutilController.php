<?php

namespace App\Http\Controllers;

use App\Models\Outil;
use Illuminate\Http\Request;

class OutilController extends Controller
{
    public function show($client_code)
    {
        $outil = Outil::where('client_code', $client_code)->first();

        if (!$outil) {
            return response()->json(['message' => 'Outils non trouvés'], 404);
        }

        return response()->json($outil);
    }
}
