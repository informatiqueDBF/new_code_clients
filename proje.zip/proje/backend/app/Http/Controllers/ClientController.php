<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Client;
use App\Models\Collaborateur;
use Illuminate\Support\Facades\Http;

class ClientController extends Controller
{

    public function show($code)
    {
        $client = Client::where('Code', $code)->first();

        if (!$client) {
            return response()->json(['error' => 'Client non trouvé'], 404);
        }

        return response()->json($client);
    }


    public function portefeuille($code)
    {
        $clients = DB::table('clients')
            ->where(function ($query) use ($code) {
                $query->where('Collaborateur_Code', $code)
                      ->orWhere('Responsable_Code', $code)
                      ->orWhere('Chef_de_mission_Code', $code);
            })
            ->whereNotIn('Famille', ['Prospect', 'prospect', 'prospects', 'Clients sortis', 'clients sortis'])
            ->select(
                'Code',
                'Nom_complet',
                'Famille',
                'adresse',
                'adresse_1',
                'adresse_2',
                'adresse_3',
                'code_postal',
                'commune',
                'departement_libelle',
                'Tel',
                'Email',
                'Date_creation',
                'Collaborateur_Code',
                'Responsable_Code',
                'Chef_de_mission_Code'
            )
            ->get();

        return response()->json($clients);
    }

    public function geocode(Request $request)
    {
        $query = $request->input('q');
    
        if (!$query) {
            return response()->json(['error' => 'Query manquante'], 400);
        }
    
        try {
            $response = Http::withHeaders([
                'User-Agent' => 'CollabMap/1.0',
                'Accept-Language' => 'fr'
            ])->get('https://nominatim.openstreetmap.org/search', [
                'q' => $query,
                'format' => 'json',
                'addressdetails' => 1,
                'limit' => 1
            ]);
    
            return response()->json($response->json());
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
    
    
    
}
