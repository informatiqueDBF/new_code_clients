<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Collaborateur;
use Illuminate\Support\Facades\Validator;

class CollaborateurController extends Controller
{
    public function index()
    {
        return Collaborateur::all();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => 'required|string|unique:collaborateurs,code',
            'nom' => 'required|string',
            'email' => 'nullable|email',
            'tel' => 'nullable|string',
            'fonction' => 'nullable|string',
            'site' => 'nullable|string',
            'droit' => 'nullable|integer',
            'present' => 'nullable|boolean',
        ]);

        $collab = Collaborateur::create($data);
        return response()->json($collab, 201);
    }

    public function update(Request $request, Collaborateur $collaborateur)
    {
        $data = $request->validate([
            'nom' => 'nullable|string',
            'email' => 'nullable|email',
            'tel' => 'nullable|string',
            'fonction' => 'nullable|string',
            'site' => 'nullable|string',
            'droit' => 'nullable|integer',
            'present' => 'nullable|boolean',
        ]);

        $collaborateur->update($data);
        return response()->json($collaborateur);
    }

    public function destroy(Collaborateur $collaborateur)
    {
        $collaborateur->delete();
        return response()->json(['message' => 'Supprimé']);
    }

    public function show($code)
    {
        $collab = Collaborateur::where('Code', $code)->first();
    
        if (!$collab) {
            return response()->json(['error' => 'Collaborateur introuvable'], 404);
        }
    
        return response()->json([
            'code' => $collab->Code,
            'nom' => $collab->Nom,
            'email' => $collab->Email,
            'tel' => $collab->Tel,
            'fonction' => $collab->Fonction,
            'site' => $collab->site,
        ]);
    }    

}
