<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class ClientStatController extends Controller
{
    public function index()
    {
        return response()->json([
            'lignes' => DB::table('clients')
            ->count(),

            'actifs' => DB::table('clients')
                ->whereNotIn(DB::raw('LOWER(Famille)'), [
                    'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
                ])
                ->count(),


            'douteux' => DB::table('clients')
                ->whereIn('Famille', ['DOUTEUX', 'douteux'])
                ->count(),

            'prospects' => DB::table('clients')
                ->whereIn('Famille', ['Prospect', 'prospects'])
                ->count(),

            'sortis' => DB::table('clients')
                ->whereIn('Famille', ['Clients sortis', 'clients sortis'])
                ->count(),

            'admin_judiciaire' => DB::table('clients')
                ->whereIn('Famille', ['Administrateur Judiciaire', 'Administrateur Judiciai'])
                ->count(),
        ]);
    }
}
