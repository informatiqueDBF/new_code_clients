<?php

namespace App\Http\Controllers;

use App\Imports\CollaborateurImport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;
use App\Exports\CollaborateurImportLogExport;
use Illuminate\Support\Facades\Storage;

class ImportCollaborateurController extends Controller
{
    public array $nullCodes = [];

    public function import(Request $request)
    {
        $request->validate([
            'fichier' => 'required|file|mimes:csv,txt,xlsx,xls|max:20480',
        ]);
    
        try {
            
            $import = new CollaborateurImport();
            Excel::import($import, $request->file('fichier'));
    
            $timestamp = now()->format('Y-m-d_H-i-s');
            $logFilename = "import_logs/collaborateur_import_{$timestamp}.xlsx";
    
            Excel::store(
                new CollaborateurImportLogExport($import->logs),
                $logFilename,
                'public'
            );
    
            return response()->json([
                'message' => 'Importation réussie.',
                'créés' => $import->created,
                'modifiés' => $import->updated,
                'erreurs' => $import->errors,
                'log' => $logFilename,
                'codes_null' => $import->nullCodes, // ← ici c’est correct
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'error' => 'Erreur lors de l\'import : ' . $e->getMessage()
            ], 500);
        }
    }
}
