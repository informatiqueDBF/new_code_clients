<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;

class TemplateController extends Controller
{
    public function clients()
    {
        return $this->downloadTemplate('template_clients.csv');
    }

    public function collaborateurs()
    {
        return $this->downloadTemplate('template_collaborateurs.csv');
    }

    public function neoexpert()
    {
        return $this->downloadTemplate('template_neoexpert.csv');
    }

    public function silae()
    {
        return $this->downloadTemplate('template_silae.csv');
    }

    private function downloadTemplate($filename)
    {
        $path = storage_path("app/templates/{$filename}");

        if (!file_exists($path)) {
            return response()->json(['error' => 'Fichier introuvable'], 404);
        }

        return response()->download($path);
    }
}
