<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Illuminate\Support\Facades\Storage;

class BackofficeController extends Controller
{
    public function stats()
    {
        $collaborateurs = DB::table('collaborateurs')
            ->where('present', 'oui')
            ->select('site', DB::raw('count(*) as total'))
            ->groupBy('site')
            ->pluck('total', 'site');

            $clients = DB::table('clients')
            ->whereNotNull('date_creation')
            ->where('date_creation', 'LIKE', '%/%/%')
            ->whereNotIn(DB::raw('LOWER(Famille)'), [
                'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
            ])
            ->selectRaw("SUBSTRING_INDEX(date_creation, '/', -1) as year, COUNT(*) as total")
            ->groupBy('year')
            ->pluck('total', 'year');
        
            $imports = DB::table('mise_a_jour')
            ->select('Type', DB::raw('count(*) as total'))
            ->groupBy('Type')
            ->pluck('total', 'Type');

            $outils = [];
            $outilsData = DB::table('outils')->get();
            
            foreach ($outilsData as $outil) {
                if ($outil->isacompta_autonome) $outils['Isacompta Autonome'] = ($outils['Isacompta Autonome'] ?? 0) + 1;
                if ($outil->isanet_compta) $outils['Isanet Compta'] = ($outils['Isanet Compta'] ?? 0) + 1;
                if ($outil->isacompta_collaboratif) $outils['Isacompta Collaboratif'] = ($outils['Isacompta Collaboratif'] ?? 0) + 1;
                if ($outil->autre_logiciel) $outils['Autre logiciel'] = ($outils['Autre logiciel'] ?? 0) + 1;
                if ($outil->neant) $outils['Néant'] = ($outils['Néant'] ?? 0) + 1;
                if ($outil->neoexpert) $outils['Neoexpert'] = ($outils['Neoexpert'] ?? 0) + 1;
                if ($outil->silae) $outils['Silae'] = ($outils['Silae'] ?? 0) + 1;
            }

            $clientsParDepartement = DB::table('clients')
                ->whereNotNull('departement_libelle')
                ->where('departement_libelle', '!=', '')
                ->whereNotIn(DB::raw('LOWER(Famille)'), [
                    'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
                ])
                ->select('departement_libelle', DB::raw('count(*) as total'))
                ->groupBy('departement_libelle')
                ->orderBy('total', 'desc')
                ->limit(10)
                ->pluck('total', 'departement_libelle');

            $topApe = DB::table('clients')
                ->whereNotNull('Ape_libelle')
                ->where('Ape_libelle', '!=', '')
                ->whereNotIn(DB::raw('LOWER(Famille)'), [
                    'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
                ])
                ->select('Ape_libelle', DB::raw('count(*) as total'))
                ->groupBy('Ape_libelle')
                ->orderBy('total', 'desc')
                ->limit(10)
                ->pluck('total', 'Ape_libelle');

            $formesJuridiques = DB::table('clients')
                ->whereNotNull('Forme_juridique')
                ->where('Forme_juridique', '!=', '')
                ->whereNotIn(DB::raw('LOWER(Famille)'), [
                    'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
                ])
                ->select('Forme_juridique', DB::raw('count(*) as total'))
                ->groupBy('Forme_juridique')
                ->orderBy('total', 'desc')
                ->limit(10)
                ->pluck('total', 'Forme_juridique');
        
            $logFiles = File::glob(storage_path('app/public/import_logs/client*.xlsx'));
            $latestFile = collect($logFiles)->sortByDesc(fn($file) => filemtime($file))->first();

            $derniereDate = null;
            $nbCrees = 0;

            \Log::info("📂 Fichier détecté : " . $latestFile);

            if ($latestFile && file_exists($latestFile)) {
                $timestamp = filemtime($latestFile);
                if ($timestamp !== false) {
                    $derniereDate = date('d/m/Y H:i', $timestamp);
                }
            
                $spreadsheet = IOFactory::load($latestFile);
                $sheet = $spreadsheet->getActiveSheet();
            
                foreach ($sheet->getRowIterator() as $row) {
                    $cell = $sheet->getCell('B' . $row->getRowIndex())->getValue();
                    if (strtolower(trim($cell)) === 'créé') {
                        $nbCrees++;
                    }
                }
            }
            

            return response()->json([
                'sites' => $collaborateurs,
                'clientsPerYear' => $clients,
                'imports' => $imports,
                'outils' => $outils,
                'clientsParDepartement' => $clientsParDepartement,
                'topApe' => $topApe,
                'formesJuridiques' => $formesJuridiques,
                'derniere_import' => [
                    'date' => $derniereDate,
                    'crees' => $nbCrees
                ]
            ]);
    }
}
