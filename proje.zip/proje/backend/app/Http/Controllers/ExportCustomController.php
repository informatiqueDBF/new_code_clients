<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\CustomExport;

class ExportCustomController extends Controller
{
    public function export(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:clients',
            'famille' => 'nullable|string',
            'outil' => 'nullable|string',
        ]);

        $query = DB::table('clients');

        if (!empty($validated['famille'])) {
            $famille = strtolower(trim($validated['famille']));
            if ($famille === 'actifs') {
                $query->whereNotIn(DB::raw('LOWER(Famille)'), [
                    'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
                ]);
            } else {
                $query->whereRaw('LOWER(Famille) = ?', [$famille]);
            }
        }

        if (!empty($validated['outil'])) {
            $columns = DB::getSchemaBuilder()->getColumnListing('outils');
            if (!in_array($validated['outil'], $columns)) {
                return response()->json(['error' => "Colonne outil invalide."], 422);
            }

            $query->join('outils', 'clients.Code', '=', 'outils.client_code')
                ->where("outils.{$validated['outil']}", '1')
                ->select(
                    'clients.Code',
                    'clients.Nom_complet',
                    'clients.Famille',
                    DB::raw("'{$validated['outil']}' as outil_utilisé")
                );
        } else {
            $query->select(
                'clients.Code',
                'clients.Nom_complet',
                'clients.Forme_juridique',
                'clients.Siret',
                'clients.Famille'
            );
        }

        $data = $query->get();

        if ($data->isEmpty()) {
            return response()->json(['error' => "Aucune donnée à exporter."], 404);
        }

        $data = $data->map(function ($item) {
            if (isset($item->Siret)) {
                $item->Siret = $this->cleanNumericString($item->Siret);
            }
            return $item;
        });

        return Excel::download(new CustomExport($data), 'export_custom.xlsx');
    }

    private function cleanNumericString($value)
    {
        return preg_replace('/\D/', '', $value); 
    }
}
