<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class ClientStatMeController extends Controller
{
    public function index($code)
    {
        $query = DB::table('clients')
            ->where(function ($q) use ($code) {
                $q->where('Collaborateur_Code', $code)
                  ->orWhere('Chef_de_mission_Code', $code)
                  ->orWhere('Responsable_Code', $code);
            });

        $actifs = (clone $query)
        ->whereNotIn(DB::raw('LOWER(Famille)'), [
            'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
        ])
        ->count();

        $douteux = (clone $query)
            ->whereIn('Famille', ['DOUTEUX', 'douteux'])
            ->count();

        $prospects = (clone $query)
            ->whereIn('Famille', ['Prospect', 'prospects'])
            ->count();

        $sortis = (clone $query)
            ->whereIn('Famille', ['Clients sortis', 'clients sortis'])
            ->count();

        $admin_judiciaire = (clone $query)
            ->whereIn('Famille', ['Administrateur Judiciaire', 'Administrateur Judiciai'])
            ->count();

        $clients = $query
            ->select('Code', 'Nom_complet', 'Tel', 'Email', 'Date_creation', 'Responsable_Code', 'Chef_de_mission_Code', 'Collaborateur_Code')
            ->get();

        return response()->json([
            'mes_clients' => $actifs + $douteux,
            'portefeuille' => $actifs + $douteux + $prospects + $sortis + $admin_judiciaire,
            'actifs' => $actifs,
            'douteux' => $douteux,
            'prospects' => $prospects,
            'sortis' => $sortis,
            'admin_judiciaire' => $admin_judiciaire,
            'clients' => $clients,
        ]);
    }
}
