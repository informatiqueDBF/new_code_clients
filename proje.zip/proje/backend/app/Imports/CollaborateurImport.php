<?php

namespace App\Imports;

use App\Models\Collaborateur;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Models\MiseAJour;


class CollaborateurImport implements ToCollection
{
    public array $logs = [];
    public int $created = 0;
    public int $updated = 0;
    public int $errors = 0;
    public array $nullCodes = [];

    public function collection(Collection $rows)
    {
        $rows->shift();

        foreach ($rows as $row) {
            try {
                $collab = Collaborateur::updateOrCreate(
                    ['Code' => trim($row[15])],
                    [
                        'Nom'     => trim($row[8] ?? ''),
                        'Email'   => trim($row[5] ?? ''),    
                        'Tel'     => trim($row[6] ?? ''),      
                        'Fonction'=> trim($row[10] ?? ''),    
                        'site'    => trim($row[1] ?? ''),      
                        'present' => strtoupper(trim($row[0])) === 'OUI' ? 'oui' : 'non', 
                        'droit'   => 0,
                        'exception' => 0,
                    ]
                );

                $this->logs[] = [
                    'Code' => $row[15],
                    'Action' => $collab->wasRecentlyCreated ? 'Créé' : 'Mis à jour',
                ];

                $collab->wasRecentlyCreated ? $this->created++ : $this->updated++;
            } catch (\Throwable $e) {
                $this->logs[] = [
                    'Code' => $row[15] ?? '??',
                    'Action' => 'Erreur',
                    'Message' => $e->getMessage(),
                ];
                if (empty(trim($row[15] ?? ''))) {
                    $this->nullCodes[] = $row;
                }
                
                $this->errors++;
            }
        }
        MiseAJour::create([
            'Date' => now()->toDateString(),
            'Type' => 'collaborateurs'
        ]);
    }
}