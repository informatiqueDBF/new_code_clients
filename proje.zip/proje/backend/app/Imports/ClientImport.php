<?php

namespace App\Imports;

use App\Models\Client;
use App\Models\Collaborateur;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Illuminate\Http\UploadedFile;
use App\Models\MiseAJour;

class ClientImport 
{
    private function cleanNumericString($value): ?string
    {
        $value = str_replace(',', '.', $value);
    
        if (preg_match('/^[0-9.]+E\+?[0-9]+$/i', $value)) {
            return sprintf('%.0f', (float) $value);
        }
    
        if (is_numeric($value)) {
            return number_format((float) $value, 0, '', '');
        }
    
        return $value;
    }
    

    public array $logs = [];
    public int $created = 0;
    public int $updated = 0;
    public int $errors = 0;
    public int $nulls = 0;
    public array $nullCodes = [];

    public function import(UploadedFile $file): void
    {
        $lines = file($file->getRealPath(), FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $lines = array_map(function ($line) {
            return mb_convert_encoding($line, 'UTF-8', 'UTF-8, ISO-8859-1, Windows-1252');
        }, $lines);
        
        if (!$lines) return;        

        array_shift($lines);
        
        foreach ($lines as $line) {
            $row = str_getcsv($line, ';');

            $code = trim($row[0] ?? '');

            if (!$code) {
                $this->nulls++;
                $this->nullCodes[] = '??';
                $this->logs[] = [
                    'Code' => '??',
                    'Action' => 'Null',
                    'Message' => 'Code manquant',
                ];
                continue;
            }

            try {
                $resp = trim($row[79] ?? '');
                $chef = trim($row[81] ?? '');
                $collab = trim($row[83] ?? '');
                
                $message = [];
                
                if ($resp && !Collaborateur::where('Code', $resp)->exists()) {
                    $this->nulls++;
                    $this->nullCodes[] = $resp;
                    $message[] = "Responsable $resp non trouvé";
                }
                
                
                if ($chef && !Collaborateur::where('Code', $chef)->exists()) {
                    $this->nulls++;
                    $this->nullCodes[] = $chef;
                    $message[] = "Chef $chef non trouvé";
                }
                
                if ($collab && !Collaborateur::where('Code', $collab)->exists()) {
                    $this->nulls++;
                    $this->nullCodes[] = $collab;
                    $message[] = "Collaborateur $collab non trouvé";
                }
                

                $client = Client::updateOrCreate(


                    ['Code' => $code],
                    [
                        'Nom_complet' => $row[1] ?? null,
                        'Qualification' => $row[3] ?? null,
                        'Famille' => $row[5] ?? null,
                        'Nature' => $row[7] ?? null,
                        'Titre' => $row[8] ?? null,
                        'Nom_denomination' => $row[11] ?? null,
                        'Nom_commercial' => $row[13] ?? null,
                        'Forme_juridique' => $row[15] ?? null,
                        'Tel_fax' => $row[57] ?? null,
                        'Tel' => $row[58] ?? null,
                        'Email' => $row[60] ?? null,
                        'Date_creation' => $row[64] ?? null,
                        'Siret' => $this->cleanNumericString($row[66] ?? null),
                        'Tva' => $this->cleanNumericString($row[67] ?? null),
                        'Ape_code' => $row[68] ?? null,
                        'Ape_libelle' => $row[69] ?? null,
                        'Nafu_code' => $row[72] ?? null,
                        'Nafu_libelle' => $row[73] ?? null,
                        'Activite_exercer' => $row[74] ?? null,
                        'Activite' => $row[75] ?? null,
                        'Activite_libelle' => $row[76] ?? null,
                        'Rcs' => $row[77] ?? null,
                        'numero' => $row[78] ?? null,
                        'Responsable_Code' => $resp,
                        'Chef_de_mission_Code' => $chef,
                        'Collaborateur_Code' => $collab,
                        'departement' => $row[36] ?? null,
                        'departement_libelle' => $row[37] ?? null,
                        'adresse' => $row[38] ?? null,
                        'adresse_1' => $row[39] ?? null,
                        'adresse_2' => $row[40] ?? null,
                        'adresse_3' => $row[41] ?? null,
                        'code_postal' => $row[42] ?? null,
                        'commune' => $row[43] ?? null,
                    ]
                );

                $this->logs[] = [
                    'Code' => $code,
                    'Action' => $client->wasRecentlyCreated ? 'Créé' : 'Mis à jour',
                    'Message' => implode(', ', $message),
                ];
                

                $client->wasRecentlyCreated ? $this->created++ : $this->updated++;



            } catch (\Throwable $e) {
                $this->errors++;
                $this->logs[] = [
                    'Code' => $code,
                    'Action' => 'Erreur',
                    'Message' => $e->getMessage(),
                ];
            }
        }
        MiseAJour::create([
            'Date' => now()->toDateString(),
            'Type' => 'client'
        ]);
    }
}
