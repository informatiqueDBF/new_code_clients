<?php

namespace App\Imports;

use App\Models\Outil;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Illuminate\Support\Facades\Log;
use App\Models\MiseAJour;

class SilaeImport implements ToCollection
{
    public array $logs = [];
    public int $created = 0;
    public int $updated = 0;
    public int $errors = 0;
    public array $nullCodes = [];

    public function collection(Collection $rows)
    {
        Outil::query()->update(['silae' => 0]);
        $this->logs[] = ['Info' => 'Tous les silae ont été réinitialisés à 0'];

        $rows->shift();

        foreach ($rows as $row) {
            try {
                $codeClient = trim($row[14]);

                if (empty($codeClient)) {
                    $this->nullCodes[] = $row;
                    $this->errors++;
                    continue;
                }

                $outil = Outil::updateOrCreate(
                    ['client_code' => $codeClient],
                    ['silae' => 1]
                );

                $this->logs[] = [
                    'Code' => $codeClient,
                    'Action' => $outil->wasRecentlyCreated ? 'Créé' : 'Mis à jour'
                ];

                $outil->wasRecentlyCreated ? $this->created++ : $this->updated++;

            } catch (\Throwable $e) {
                $this->logs[] = [
                    'Code' => $row[14] ?? '??',
                    'Action' => 'Erreur',
                    'Message' => $e->getMessage(),
                ];
                $this->errors++;
            }
        }

        MiseAJour::create([
            'Date' => now()->toDateString(),
            'Type' => 'silae'
        ]);
    }
}