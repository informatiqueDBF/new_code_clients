<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Outil extends Model
{
    protected $fillable = [
        'client_code',
        'isacompta_autonome',
        'isanet_compta',
        'isacompta_collaboratif',
        'autre_logiciel',
        'neant',
        'neoexpert',
        'silae',
    ];
}
