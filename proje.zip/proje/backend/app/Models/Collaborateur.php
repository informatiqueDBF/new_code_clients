<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Collaborateur extends Model
{
    
    protected $table = 'collaborateurs';
    protected $primaryKey = 'Code';
    public $incrementing = false;
    protected $keyType = 'string';
    
    protected $fillable = [
        'Code', 'Nom', 'Email', 'Tel', 'Fonction',
        'site', 'present', 'droit', 'exception',
    ];

    public $timestamps = true;
}

