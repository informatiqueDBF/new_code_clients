<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Note extends Model
{
    protected $fillable = [
        'client_code', 'contenu', 'couleur', 'position_x', 'position_y', 'fichier'
    ];

    public function client()
    {
        return $this->belongsTo(Client::class, 'client_code', 'Code');
    }
}
