<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    protected $primaryKey = 'Code';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'Code', 'Nom_complet', 'Qualification', 'Famille', 'Nature', 'Titre',
        'Nom_denomination', 'Nom_commercial', 'Forme_juridique', 'Tel_fax', 'Tel', 'Email',
        'Date_creation', 'Tva', 'Siret', 'Ape_code', 'Ape_libelle', 'Nafu_code', 'Nafu_libelle',
        'Activite_exercer', 'Activite', 'Activite_libelle', 'Rcs', 'numero', 'Responsable_Code',
        'Chef_de_mission_Code', 'Collaborateur_Code', 'departement', 'departement_libelle',
        'adresse', 'adresse_1', 'adresse_2', 'adresse_3', 'code_postal', 'commune'
    ];
    public function collaborateur()
    {
        return $this->belongsTo(Collaborateur::class, 'Collaborateur_Code', 'Code');
    }

}
