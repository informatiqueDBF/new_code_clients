<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MiseAJour extends Model
{
    protected $table = 'mise_a_jour';

    public $timestamps = false;

    protected $fillable = ['Date', 'Type'];
}
