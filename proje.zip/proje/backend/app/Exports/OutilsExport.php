<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithTitle;

class OutilsExport implements FromCollection, WithHeadings, WithTitle
{
    public function collection()
    {
        $outils = [];
        $outilsData = DB::table('outils')
            ->join('clients', 'outils.client_code', '=', 'clients.Code')
            ->whereNotIn(DB::raw('LOWER(clients.Famille)'), [
                'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
            ])
            ->select('outils.*', 'clients.Nom_complet')
            ->get();
        
        $stats = [];
        foreach ($outilsData as $outil) {
            if ($outil->isacompta_autonome) $stats[] = ['Outil' => 'Isacompta Autonome', 'Client' => $outil->Nom_complet, 'Code Client' => $outil->client_code];
            if ($outil->isanet_compta) $stats[] = ['Outil' => 'Isanet Compta', 'Client' => $outil->Nom_complet, 'Code Client' => $outil->client_code];
            if ($outil->isacompta_collaboratif) $stats[] = ['Outil' => 'Isacompta Collaboratif', 'Client' => $outil->Nom_complet, 'Code Client' => $outil->client_code];
            if ($outil->autre_logiciel) $stats[] = ['Outil' => 'Autre logiciel', 'Client' => $outil->Nom_complet, 'Code Client' => $outil->client_code];
            if ($outil->neant) $stats[] = ['Outil' => 'Néant', 'Client' => $outil->Nom_complet, 'Code Client' => $outil->client_code];
            if ($outil->neoexpert) $stats[] = ['Outil' => 'Neoexpert', 'Client' => $outil->Nom_complet, 'Code Client' => $outil->client_code];
            if ($outil->silae) $stats[] = ['Outil' => 'Silae', 'Client' => $outil->Nom_complet, 'Code Client' => $outil->client_code];
        }

        return collect($stats);
    }

    public function headings(): array
    {
        return [
            'Outil',
            'Client',
            'Code Client'
        ];
    }

    public function title(): string
    {
        return 'Outils Clients';
    }
}
