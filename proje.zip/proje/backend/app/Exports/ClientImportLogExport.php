<?php

namespace App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ClientImportLogExport implements FromCollection, WithHeadings
{
    protected array $logs;

    public function __construct(array $logs)
    {
        $this->logs = $logs;
    }

    public function collection()
    {
        return collect($this->logs);
    }

    public function headings(): array
    {
        return ['Code', 'Action', 'Message'];
    }
}
