<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithTitle;

class ClientsParDepartementExport implements FromCollection, WithHeadings, WithTitle
{
    public function collection()
    {
        return DB::table('clients')
            ->whereNotNull('departement_libelle')
            ->where('departement_libelle', '!=', '')
            ->whereNotIn(DB::raw('LOWER(Famille)'), [
                'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
            ])
            ->select(
                'departement_libelle as Département',
                'Code',
                'Nom_complet as Nom',
                'commune as Commune',
                'code_postal as Code_Postal'
            )
            ->orderBy('departement_libelle')
            ->get();
    }

    public function headings(): array
    {
        return [
            'Département',
            'Code Client',
            'Nom Client',
            'Commune',
            'Code Postal'
        ];
    }

    public function title(): string
    {
        return 'Clients par Département';
    }
}
