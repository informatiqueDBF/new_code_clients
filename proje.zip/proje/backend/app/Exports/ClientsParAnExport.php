<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ClientsParAnExport implements FromArray, WithHeadings
{
    public function array(): array
    {
        $data = DB::table('clients')
            ->whereNotNull('date_creation')
            ->where('date_creation', 'LIKE', '%/%/%')
            ->selectRaw("SUBSTRING_INDEX(date_creation, '/', -1) as year, COUNT(*) as total")
            ->groupBy('year')
            ->pluck('total', 'year')
            ->toArray();

        return collect($data)->map(function ($total, $year) {
            return [$year, $total];
        })->values()->toArray();
    }

    public function headings(): array
    {
        return ['Année', 'Nombre de clients créés'];
    }
}
