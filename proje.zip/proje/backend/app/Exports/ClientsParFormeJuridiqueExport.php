<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithTitle;

class ClientsParFormeJuridiqueExport implements FromCollection, WithHeadings, WithTitle
{
    public function collection()
    {
        return DB::table('clients')
            ->whereNotNull('Forme_juridique')
            ->where('Forme_juridique', '!=', '')
            ->whereNotIn(DB::raw('LOWER(Famille)'), [
                'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
            ])
            ->select(
                'Forme_juridique as Forme_Juridique',
                'Code',
                'Nom_complet as Nom',
                'Date_creation as Date_Création',
                'commune as Commune'
            )
            ->orderBy('Forme_juridique')
            ->get();
    }

    public function headings(): array
    {
        return [
            'Forme Juridique',
            'Code Client',
            'Nom Client',
            'Date de Création',
            'Commune'
        ];
    }

    public function title(): string
    {
        return 'Clients par Forme Juridique';
    }
}
