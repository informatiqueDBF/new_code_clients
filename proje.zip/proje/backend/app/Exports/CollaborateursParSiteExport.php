<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;

class CollaborateursParSiteExport implements FromArray, WithHeadings
{
    public function array(): array
    {
        $data = DB::table('collaborateurs')
            ->where('present', 'oui')
            ->select('site', DB::raw('count(*) as total'))
            ->groupBy('site')
            ->pluck('total', 'site')
            ->toArray();

        return collect($data)->map(function ($total, $site) {
            return [$site, $total];
        })->values()->toArray();
    }

    public function headings(): array
    {
        return ['Site', 'Collaborateurs présents'];
    }
}
