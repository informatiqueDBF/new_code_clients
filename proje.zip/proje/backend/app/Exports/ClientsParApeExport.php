<?php

namespace App\Exports;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithTitle;

class ClientsParApeExport implements FromCollection, WithHeadings, WithTitle
{
    public function collection()
    {
        return DB::table('clients')
            ->whereNotNull('Ape_libelle')
            ->where('Ape_libelle', '!=', '')
            ->whereNotIn(DB::raw('LOWER(Famille)'), [
                'prospect', 'prospects', 'clients sortis', 'douteux', 'administrateur judiciaire', 'administrateur judiciai'
            ])
            ->select(
                'Ape_libelle as Secteur_Activité',
                'Ape_code as Code_APE',
                'Code',
                'Nom_complet as Nom',
                'commune as Commune'
            )
            ->orderBy('Ape_libelle')
            ->get();
    }

    public function headings(): array
    {
        return [
            'Secteur d\'Activité',
            'Code APE',
            'Code Client',
            'Nom Client',
            'Commune'
        ];
    }

    public function title(): string
    {
        return 'Clients par Secteur APE';
    }
}
